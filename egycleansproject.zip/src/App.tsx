import { AppProvider } from './state/AppContext'
import { Phone } from './components/Phone'

export default function App() {
  return (
    <AppProvider>
      <Phone />
    </AppProvider>
  )
}
