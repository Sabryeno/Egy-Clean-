import { useVals } from '../state/AppContext'
import { css } from '../lib/css'
import { BackArrow } from '../components/ui'

export function Summary() {
  const v = useVals()
  if (!v.isSummary) return null
  const co = v.co
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('padding:6px 20px 14px;background:var(--card);border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px')}>
        <div onClick={v.goSchedule} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div>
        <div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{v.L.summary}</div>
      </div>
      <div style={css('padding:18px 20px 20px;display:flex;flex-direction:column;gap:14px')}>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:13px;display:flex;gap:12px;align-items:center')}><div style={css(`width:50px;height:50px;border-radius:12px;background:${co.grad};color:#fff;font-weight:800;font-size:22px;display:flex;align-items:center;justify-content:center`)}>{co.mono}</div><div style={{ flex: 1 }}><div style={css('font-weight:800;font-size:15px;color:var(--ink)')}>{co.name}</div><div style={css('font-size:12px;color:var(--soft);font-weight:500;margin-top:2px')}>⭐ {co.rating} · {co.tag}</div></div></div>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px')}>
          <div style={css('font-weight:800;font-size:13.5px;color:var(--ink);margin-bottom:6px')}>{v.L.details}</div>
          {v.summaryRows.map((r, i) => (<div key={i} style={css('display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line2)')}><span style={css('font-size:12.5px;color:var(--soft);font-weight:500')}>{r.k}</span><span style={css('font-size:12.5px;color:var(--ink);font-weight:700;text-align:end')}>{r.v}</span></div>))}
        </div>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px')}>
          <div style={css('font-weight:800;font-size:13.5px;color:var(--ink);margin-bottom:8px')}>{v.L.priceBreakdown}</div>
          <div style={css('display:flex;justify-content:space-between;padding:6px 0')}><span style={css('font-size:13px;color:var(--soft);font-weight:500')}>{v.L.labour}</span><span style={css('font-size:13px;color:var(--ink);font-weight:700')}>{v.priceLabour}</span></div>
          <div style={css('display:flex;justify-content:space-between;padding:6px 0')}><span style={css('font-size:13px;color:var(--soft);font-weight:500')}>{v.L.supplies}</span><span style={css('font-size:13px;color:var(--ink);font-weight:700')}>{v.priceSupplies}</span></div>
          <div style={css('display:flex;justify-content:space-between;padding:6px 0;border-top:1px solid var(--line2);margin-top:4px')}><span style={css('font-size:13px;color:var(--soft);font-weight:600')}>{v.L.subtotal}</span><span style={css('font-size:13px;color:var(--ink);font-weight:700')}>{v.priceSubtotal}</span></div>
          <div style={css('display:flex;justify-content:space-between;padding:6px 0')}><span style={css('font-size:13px;color:var(--soft);font-weight:500')}>{v.L.platformFee}</span><span style={css('font-size:13px;color:var(--ink);font-weight:700')}>{v.priceFee}</span></div>
          <div style={css('display:flex;justify-content:space-between;padding:6px 0')}><span style={css('font-size:13px;color:var(--soft);font-weight:500')}>{v.L.vat}</span><span style={css('font-size:13px;color:var(--ink);font-weight:700')}>{v.priceVat}</span></div>
          <div style={css('display:flex;justify-content:space-between;padding:11px 0 2px;border-top:2px solid var(--line);margin-top:5px')}><span style={css('font-size:15px;color:var(--ink);font-weight:800')}>{v.L.total}</span><span style={css('font-size:17px;color:#1E63FF;font-weight:800')}>{v.priceTotal}</span></div>
        </div>
        <div onClick={v.toggleAgree} style={css(`background:${v.agreeBg};border:1px solid ${v.agreeBorder};border-radius:16px;padding:14px;display:flex;gap:12px;cursor:pointer`)}><div style={css(`width:22px;height:22px;border-radius:7px;flex:none;background:${v.checkBg};border:2px solid ${v.checkBorder};display:flex;align-items:center;justify-content:center`)}>{v.checkMark}</div><div><div style={css('font-weight:700;font-size:12.5px;color:var(--ink)')}>{v.L.cancelTitle}</div><div style={css('font-size:11.5px;color:var(--soft);margin-top:2px;font-weight:500;line-height:1.4')}>{v.L.cancelBody}</div></div></div>
      </div>
    </div>
  )
}

export function Payment() {
  const v = useVals()
  if (!v.isPayment) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('padding:6px 20px 14px;background:var(--card);border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px')}><div onClick={v.goSummary} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div><div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{v.L.payment}</div></div>
      <div style={css('padding:18px 20px 20px')}>
        <div style={css('font-weight:800;font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px')}>{v.L.choosePay}</div>
        <div style={css('display:flex;flex-direction:column;gap:10px')}>
          {v.payMethods.map((p, i) => (<div key={i} onClick={p.onSelect} style={css(`${p.cardStyle};display:flex;align-items:center;gap:13px;padding:14px 15px;border-radius:14px;cursor:pointer`)}><div style={css(`width:38px;height:38px;border-radius:10px;background:${p.iconBg};display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:${p.iconColor}`)}>{p.icon}</div><div style={{ flex: 1 }}><div style={css('font-weight:700;font-size:14px;color:var(--ink)')}>{p.label}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:1px')}>{p.sub}</div></div><div style={css(`width:22px;height:22px;border-radius:50%;border:2px solid ${p.radioBorder};display:flex;align-items:center;justify-content:center`)}>{p.radioDot}</div></div>))}
        </div>
      </div>
    </div>
  )
}

export function Success() {
  const v = useVals()
  if (!v.isSuccess) return null
  return (
    <div style={css('animation:fadein .3s ease;padding:24px 20px 20px;text-align:center;min-height:640px;display:flex;flex-direction:column')}>
      <div style={css('margin:20px auto 0;width:104px;height:104px;border-radius:50%;background:rgba(22,179,100,.12);display:flex;align-items:center;justify-content:center;animation:pop .5s cubic-bezier(.2,.9,.3,1.2) both')}><div style={css('width:74px;height:74px;border-radius:50%;background:#16B364;display:flex;align-items:center;justify-content:center')}><svg width="38" height="38" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg></div></div>
      <div style={css('font-weight:800;font-size:23px;color:var(--ink);margin-top:20px;letter-spacing:-.4px')}>{v.successHeadline}</div>
      <div style={css('font-size:13.5px;color:var(--soft);margin-top:6px;font-weight:500')}>{v.L.bookingConfirmed}</div>
      <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin-top:22px;text-align:start')}>
        {v.successRows.map((r, i) => (<div key={i} style={css('display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--line2)')}><span style={css('font-size:12.5px;color:var(--soft);font-weight:500')}>{r.k}</span><span style={css('font-size:12.5px;color:var(--ink);font-weight:700;text-align:end')}>{r.v}</span></div>))}
        <div style={css('display:flex;justify-content:space-between;padding:11px 0 2px')}><span style={css('font-size:14px;color:var(--ink);font-weight:800')}>{v.L.amountPaid}</span><span style={css('font-size:16px;color:#16B364;font-weight:800')}>{v.priceTotal}</span></div>
      </div>
      <div style={css('display:flex;gap:10px;margin-top:16px')}><div style={css('flex:1;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:13px;font-weight:700;font-size:13px;color:var(--ink);display:flex;align-items:center;justify-content:center;gap:7px')}><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 2h9l5 5v15H6z" stroke="var(--ink)" strokeWidth="2" strokeLinejoin="round" /><path d="M9 13h6M9 17h6" stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" /></svg>{v.L.invoice}</div><div style={css('flex:1;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:13px;font-weight:700;font-size:13px;color:var(--ink);display:flex;align-items:center;justify-content:center;gap:7px')}><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="6" cy="12" r="2.4" stroke="var(--ink)" strokeWidth="2" /><circle cx="18" cy="6" r="2.4" stroke="var(--ink)" strokeWidth="2" /><circle cx="18" cy="18" r="2.4" stroke="var(--ink)" strokeWidth="2" /><path d="M8 11l8-4M8 13l8 4" stroke="var(--ink)" strokeWidth="2" /></svg>{v.L.share}</div></div>
      <div onClick={v.viewBookings} style={css('margin-top:14px;background:#1E63FF;color:#fff;border-radius:14px;padding:16px;font-weight:800;font-size:15px;cursor:pointer')}>{v.L.viewBookings}</div>
    </div>
  )
}

export function Bookings() {
  const v = useVals()
  if (!v.isBookings) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('padding:14px 20px 0;background:var(--card);border-bottom:1px solid var(--line)')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between')}><div style={css('font-weight:800;font-size:19px;color:var(--ink)')}>{v.L.myBookings}</div><div onClick={v.toggleLang} style={css('height:32px;padding:0 11px;border-radius:30px;background:var(--field);display:flex;align-items:center;font-size:12px;font-weight:800;color:var(--ink);cursor:pointer')}>{v.langLabel}</div></div>
        <div style={css('display:flex;gap:20px;margin-top:14px')}><div onClick={v.tabUpcoming} style={css(v.tabUpStyle)}>{v.L.upcoming}</div><div onClick={v.tabPast} style={css(v.tabPastStyle)}>{v.L.past}</div></div>
      </div>
      {v.hasListItems && (
        <div style={css('padding:16px 20px;display:flex;flex-direction:column;gap:13px')}>
          {v.historyList.map((b, i) => (
            <div key={i} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px')}>
              <div style={css('display:flex;justify-content:space-between;align-items:flex-start')}><div style={css('display:flex;gap:11px;align-items:center')}><div style={css(`width:44px;height:44px;border-radius:11px;background:${b.grad};color:#fff;font-weight:800;font-size:19px;display:flex;align-items:center;justify-content:center`)}>{b.mono}</div><div><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{b.name}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:1px')}>{b.service}</div></div></div><span style={css(b.badgeStyle)}>{b.badge}</span></div>
              <div style={css('margin-top:10px')}><span style={css(b.payStyle)}>{b.payLabel}</span></div>
              <div style={css('display:flex;justify-content:space-between;align-items:center;margin-top:11px;padding-top:12px;border-top:1px solid var(--line2)')}><div style={css('font-size:11.5px;color:var(--soft);font-weight:600')}><div>{b.datetime}</div><div style={css('margin-top:2px;color:var(--muted)')}>{b.id}</div></div><div style={css('font-weight:800;font-size:16px;color:var(--ink)')}>{b.total}</div></div>
            </div>
          ))}
        </div>
      )}
      {v.emptyList && (
        <div style={css('padding:60px 30px;text-align:center')}><div style={{ fontSize: '60px' }}>🧺</div><div style={css('font-weight:800;font-size:17px;color:var(--ink);margin-top:14px')}>{v.emptyTitle}</div><div style={css('font-size:13px;color:var(--soft);margin-top:6px;font-weight:500;line-height:1.5')}>{v.L.emptyBody}</div><div onClick={v.goHome} style={css('display:inline-block;margin-top:18px;background:#1E63FF;color:#fff;border-radius:14px;padding:13px 24px;font-weight:800;font-size:14px;cursor:pointer')}>{v.L.browse}</div></div>
      )}
    </div>
  )
}

export function Account() {
  const v = useVals()
  if (!v.isAccount) return null
  return (
    <div style={css('animation:fadein .25s ease;padding:14px 20px 24px')}>
      <div style={css('font-weight:800;font-size:20px;color:var(--ink)')}>{v.L.account}</div>
      <div style={css('margin-top:16px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:18px;text-align:center')}>
        <div onClick={v.addPhoto} style={css(`width:76px;height:76px;border-radius:50%;margin:0 auto;position:relative;cursor:pointer;background:${v.photoBg};display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;font-weight:800`)}>{v.photoContent}<div style={css(`position:absolute;bottom:0;${v.photoBtnSide}:0;width:26px;height:26px;border-radius:50%;background:#1E63FF;border:2px solid var(--card);display:flex;align-items:center;justify-content:center`)}><svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M4 8h3l2-2h6l2 2h3v11H4z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" /><circle cx="12" cy="13" r="3" stroke="#fff" strokeWidth="2" /></svg></div></div>
        <div style={css('font-weight:800;font-size:17px;color:var(--ink);margin-top:12px')}>{v.pName}</div>
        <div style={css('font-size:12.5px;color:var(--soft);font-weight:500;margin-top:2px')}>{v.pEmail} · {v.pPhone}</div>
        <div style={css('font-size:11.5px;color:#1E63FF;font-weight:700;margin-top:8px')}>{v.photoHint}</div>
      </div>
      <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:22px;margin-bottom:10px')}>{v.L.wallet}</div>
      <div style={css('background:linear-gradient(135deg,#1E63FF,#1546C0);border-radius:18px;padding:18px;color:#fff;position:relative;overflow:hidden')}>
        <div style={css('position:absolute;right:-14px;top:-14px;font-size:80px;opacity:.13')}>💳</div>
        <div style={css('font-size:12px;color:rgba(255,255,255,.82);font-weight:600')}>{v.L.walletBalance}</div>
        <div style={css('font-weight:800;font-size:26px;margin-top:3px')}>{v.walletBal}</div>
        <div style={css('margin-top:16px;font-size:14px;font-weight:700;letter-spacing:2px')}>•••• •••• •••• 4821</div>
        <div style={css('display:flex;justify-content:space-between;align-items:center;margin-top:8px')}><span style={css('font-size:11.5px;color:rgba(255,255,255,.82);font-weight:600')}>Rana Mostafa</span><span style={css('font-size:11.5px;color:rgba(255,255,255,.82);font-weight:600')}>{v.L.expires} 08/28</span></div>
      </div>
      <div onClick={v.addCard} style={css('margin-top:10px;background:var(--card);border:1px dashed var(--line);border-radius:14px;padding:14px;text-align:center;font-weight:700;font-size:13px;color:#1E63FF;cursor:pointer')}>＋ {v.L.addCard}</div>
      <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:22px;margin-bottom:10px')}>{v.L.settings}</div>
      <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden')}>
        <div onClick={v.openCustProfile} style={css('display:flex;align-items:center;gap:12px;padding:14px 15px;border-bottom:1px solid var(--line2);cursor:pointer')}><span style={{ fontSize: '17px' }}>👤</span><span style={css('flex:1;font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.personalDetails}</span><span style={css('color:var(--muted);font-size:16px')}>{v.chevron}</span></div>
        <div onClick={v.toggleLang} style={css('display:flex;align-items:center;gap:12px;padding:14px 15px;border-bottom:1px solid var(--line2);cursor:pointer')}><span style={{ fontSize: '17px' }}>🌐</span><span style={css('flex:1;font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.language}</span><span style={css('font-size:12px;font-weight:700;color:#1E63FF')}>{v.langFull}</span></div>
        <div onClick={v.toggleTheme} style={css('display:flex;align-items:center;gap:12px;padding:14px 15px;border-bottom:1px solid var(--line2);cursor:pointer')}><span style={{ fontSize: '17px' }}>{v.themeIcon}</span><span style={css('flex:1;font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.appearance}</span><span style={css('font-size:12px;font-weight:700;color:#1E63FF')}>{v.themeLabel}</span></div>
        <div style={css('display:flex;align-items:center;gap:12px;padding:14px 15px')}><span style={{ fontSize: '17px' }}>💬</span><span style={css('flex:1;font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.help}</span><span style={css('color:var(--muted);font-size:16px')}>{v.chevron}</span></div>
      </div>
      <div onClick={v.logout} style={css('margin-top:16px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:15px;text-align:center;font-weight:700;font-size:14px;color:#E5484D;cursor:pointer')}>{v.L.logout}</div>
    </div>
  )
}

export function CustNotifs() {
  const v = useVals()
  if (!v.isCustNotifs) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('padding:6px 20px 14px;background:var(--card);border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px')}><div onClick={v.goHome} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div><div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{v.L.notifications}</div></div>
      <div style={css('padding:16px 20px;display:flex;flex-direction:column;gap:12px')}>
        {v.custNotifList.map((n, i) => (
          <div key={i} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px;display:flex;gap:12px')}><div style={css(`width:40px;height:40px;border-radius:11px;background:${n.iconBg};display:flex;align-items:center;justify-content:center;font-size:19px;flex:none`)}>{n.icon}</div><div style={{ flex: 1 }}><div style={css('font-weight:800;font-size:13.5px;color:var(--ink)')}>{n.title}</div><div style={css('font-size:12px;color:var(--soft);font-weight:500;margin-top:2px;line-height:1.4')}>{n.body}</div><div style={css('font-size:11px;color:var(--muted);font-weight:600;margin-top:5px')}>{n.time}</div></div>{n.unread && (<span style={css('width:8px;height:8px;border-radius:50%;background:#1E63FF;flex:none;margin-top:4px')} />)}</div>
        ))}
      </div>
    </div>
  )
}

export function CustProfile() {
  const v = useVals()
  if (!v.isCustProfile) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('background:linear-gradient(155deg,#1E63FF,#1546C0);padding:2px 20px 26px;color:#fff;border-radius:0 0 26px 26px')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between')}>
          <div onClick={v.backToAccount} style={css('width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="#fff" flip={v.backFlip} /></div>
          <div style={css('font-weight:800;font-size:16px')}>{v.profileTitle}</div>
          {v.notEditingProfile && (<div onClick={v.startEditProfile} style={css('height:34px;padding:0 13px;border-radius:30px;background:rgba(255,255,255,.18);display:flex;align-items:center;gap:5px;font-size:12.5px;font-weight:800;cursor:pointer')}><svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M4 20h4L18.5 9.5a2 2 0 000-3l-.99-.99a2 2 0 00-3 0L4 16v4z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" /></svg>{v.editWord2}</div>)}
          {v.editingProfile && (<div style={{ width: '36px' }} />)}
        </div>
        <div style={css('text-align:center;margin-top:8px')}>
          <div onClick={v.addPhoto} style={css(`width:82px;height:82px;border-radius:50%;margin:0 auto;position:relative;cursor:pointer;background:${v.photoBg2};display:flex;align-items:center;justify-content:center;font-size:34px;color:#1546C0;font-weight:800;border:3px solid rgba(255,255,255,.4)`)}>{v.photoContent2}<div style={css(`position:absolute;bottom:0;${v.photoBtnSide}:0;width:26px;height:26px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center`)}><svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M4 8h3l2-2h6l2 2h3v11H4z" stroke="#1E63FF" strokeWidth="2" strokeLinejoin="round" /><circle cx="12" cy="13" r="3" stroke="#1E63FF" strokeWidth="2" /></svg></div></div>
          <div style={css('font-weight:800;font-size:19px;margin-top:12px')}>{v.pName}</div>
          <div style={css('font-size:12px;color:rgba(255,255,255,.82);font-weight:500;margin-top:3px')}>{v.memberSince}</div>
        </div>
      </div>
      <div style={css('padding:18px 20px 24px')}>
        {v.editingProfile && (
          <div style={css('display:flex;flex-direction:column;gap:13px')}>
            <div><div style={css('font-size:11.5px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.fullNameW}</div><input value={v.pName} onChange={v.onPName} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
            <div><div style={css('font-size:11.5px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.emailW}</div><input value={v.pEmail} onChange={v.onPEmail} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
            <div><div style={css('font-size:11.5px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.mobileW}</div><input value={v.pPhone} onChange={v.onPPhone} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
            <div><div style={css('font-size:11.5px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.cityW}</div><input value={v.pCity} onChange={v.onPCity} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
            <div onClick={v.saveProfile} style={css('margin-top:4px;background:#1E63FF;color:#fff;border-radius:14px;padding:15px;text-align:center;font-weight:800;font-size:15px;cursor:pointer')}>{v.saveProfileW}</div>
          </div>
        )}
        {v.notEditingProfile && (
          <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden')}>
            <div style={css('display:flex;align-items:center;gap:12px;padding:15px;border-bottom:1px solid var(--line2)')}><div style={css('width:36px;height:36px;border-radius:10px;background:rgba(30,99,255,.1);display:flex;align-items:center;justify-content:center;font-size:15px')}>👤</div><div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.fullNameW}</div><div style={css('font-weight:700;font-size:13.5px;color:var(--ink);margin-top:1px')}>{v.pName}</div></div></div>
            <div style={css('display:flex;align-items:center;gap:12px;padding:15px;border-bottom:1px solid var(--line2)')}><div style={css('width:36px;height:36px;border-radius:10px;background:rgba(22,179,100,.12);display:flex;align-items:center;justify-content:center;font-size:15px')}>✉️</div><div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.emailW}</div><div style={css('font-weight:700;font-size:13.5px;color:var(--ink);margin-top:1px')}>{v.pEmail}</div></div></div>
            <div style={css('display:flex;align-items:center;gap:12px;padding:15px;border-bottom:1px solid var(--line2)')}><div style={css('width:36px;height:36px;border-radius:10px;background:rgba(245,166,35,.15);display:flex;align-items:center;justify-content:center;font-size:15px')}>📱</div><div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.mobileW}</div><div style={css('font-weight:700;font-size:13.5px;color:var(--ink);margin-top:1px')}>{v.pPhone}</div></div></div>
            <div style={css('display:flex;align-items:center;gap:12px;padding:15px')}><div style={css('width:36px;height:36px;border-radius:10px;background:rgba(124,58,237,.12);display:flex;align-items:center;justify-content:center;font-size:15px')}>📍</div><div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.cityW}</div><div style={css('font-weight:700;font-size:13.5px;color:var(--ink);margin-top:1px')}>{v.pCity}</div></div></div>
          </div>
        )}
      </div>
    </div>
  )
}
