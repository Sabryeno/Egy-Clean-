import { useVals } from '../state/AppContext'
import { css } from '../lib/css'
import { BackArrow } from '../components/ui'

export function Splash() {
  const v = useVals()
  if (!v.isSplash) return null
  return (
    <div style={css('height:740px;background:linear-gradient(160deg,#1E63FF,#1546C0);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff')}>
      <div style={css('position:relative;display:flex;align-items:center;justify-content:center')}>
        <div style={css('position:absolute;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,.3);animation:ring 1.8s ease-out infinite')} />
        <div style={css('width:104px;height:104px;border-radius:30px;background:#fff;display:flex;align-items:center;justify-content:center;font-size:52px;animation:logoIn .9s cubic-bezier(.2,.9,.3,1.3) both')}>🧼</div>
      </div>
      <div style={css('margin-top:26px;font-weight:800;font-size:28px;letter-spacing:-.5px;animation:fadein 1s ease .5s both')}>{v.L.appName}</div>
      <div style={css('margin-top:8px;font-size:13.5px;color:rgba(255,255,255,.85);font-weight:500;animation:fadein 1s ease .8s both')}>{v.L.tagline}</div>
    </div>
  )
}

export function Login() {
  const v = useVals()
  if (!v.isLogin) return null
  return (
    <div style={css('animation:fadein .3s ease;padding:14px 24px 30px')}>
      <div style={css('display:flex;justify-content:flex-end')}>
        <div onClick={v.toggleLang} style={css('height:34px;padding:0 13px;border-radius:30px;background:var(--field);border:1px solid var(--line);display:flex;align-items:center;font-size:12.5px;font-weight:800;color:var(--ink);cursor:pointer')}>{v.langLabel}</div>
      </div>
      <div style={css('text-align:center;margin-top:14px')}>
        <div style={css('width:70px;height:70px;border-radius:20px;background:linear-gradient(150deg,#1E63FF,#1546C0);display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto')}>🧼</div>
      </div>
      <div style={css('text-align:center;font-weight:800;font-size:24px;color:var(--ink);margin-top:18px;letter-spacing:-.4px')}>{v.L.welcomeBack}</div>
      <div style={css('text-align:center;font-size:13px;color:var(--soft);margin-top:5px;font-weight:500')}>{v.L.loginSub}</div>
      <div style={css('display:flex;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:4px;margin-top:22px')}>
        <div onClick={v.pickIndividual} style={css(v.segIndividual)}>👤 {v.L.individual}</div>
        <div onClick={v.pickCorporate} style={css(v.segCorporate)}>🏢 {v.L.corporate}</div>
      </div>
      <div style={css('margin-top:18px')}>
        <div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.email}</div>
        <input placeholder="name@email.com" style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:15px;font-size:14px;color:var(--ink);outline:none')} />
        <div style={css('font-size:12px;font-weight:700;color:var(--soft);margin:14px 0 6px')}>{v.L.password}</div>
        <input type="password" defaultValue="password1" style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:15px;font-size:14px;color:var(--ink);outline:none')} />
      </div>
      <div onClick={v.doLogin} style={css('margin-top:22px;background:#1E63FF;color:#fff;border-radius:14px;padding:16px;text-align:center;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 10px 22px -8px rgba(30,99,255,.6)')}>{v.loginBtnLabel}</div>
      <div style={css('text-align:center;margin-top:18px;font-size:13px;color:var(--soft);font-weight:500')}>{v.L.noAccount} <span onClick={v.goSignup} style={css('color:#1E63FF;font-weight:700;cursor:pointer')}>{v.L.createAccount}</span></div>
    </div>
  )
}

export function Signup() {
  const v = useVals()
  if (!v.isSignup) return null
  return (
    <div style={css('animation:fadein .3s ease;padding:6px 24px 30px')}>
      <div onClick={v.goLogin} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div>
      <div style={css('font-weight:800;font-size:24px;color:var(--ink);margin-top:14px;letter-spacing:-.4px')}>{v.L.createAccount}</div>
      <div style={css('font-size:13px;color:var(--soft);margin-top:5px;font-weight:500')}>{v.L.signupSub}</div>
      <div style={css('display:flex;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:4px;margin-top:20px')}>
        <div onClick={v.pickIndividual} style={css(v.segIndividual)}>👤 {v.L.individual}</div>
        <div onClick={v.pickCorporate} style={css(v.segCorporate)}>🏢 {v.L.corporate}</div>
      </div>
      <div style={css('margin-top:18px;display:flex;flex-direction:column;gap:13px')}>
        <div><div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.signupNameLabel}</div><input placeholder={v.signupNamePh} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:15px;font-size:14px;color:var(--ink);outline:none')} /></div>
        <div><div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.email}</div><input placeholder="name@email.com" style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:15px;font-size:14px;color:var(--ink);outline:none')} /></div>
        <div><div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.mobileNumber}</div><input placeholder="+20 1XX XXX XXXX" style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:15px;font-size:14px;color:var(--ink);outline:none')} /></div>
      </div>
      <div onClick={v.doSignup} style={css('margin-top:22px;background:#1E63FF;color:#fff;border-radius:14px;padding:16px;text-align:center;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 10px 22px -8px rgba(30,99,255,.6)')}>{v.signupBtnLabel}</div>
      <div style={css('text-align:center;margin-top:16px;font-size:13px;color:var(--soft);font-weight:500')}>{v.L.haveAccount} <span onClick={v.goLogin} style={css('color:#1E63FF;font-weight:700;cursor:pointer')}>{v.L.login}</span></div>
    </div>
  )
}

export function CorpReg() {
  const v = useVals()
  if (!v.isCorpReg) return null
  return (
    <div style={css('animation:fadein .3s ease;padding:6px 22px 30px')}>
      <div onClick={v.goSignup} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div>
      <div style={css('font-weight:800;font-size:22px;color:var(--ink);margin-top:14px;letter-spacing:-.3px')}>{v.L.corpRegTitle}</div>
      <div style={css('font-size:12.5px;color:var(--soft);margin-top:5px;font-weight:500;line-height:1.5')}>{v.L.corpRegSub}</div>
      <div style={css('margin-top:18px;display:flex;flex-direction:column;gap:12px')}>
        <div><div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.companyName}</div><input placeholder={v.L.companyNamePh} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
        {v.uploads.map((u, i) => (
          <div key={i} onClick={u.onUpload} style={css(`${u.style};border-radius:14px;padding:14px 15px;display:flex;align-items:center;gap:12px;cursor:pointer`)}>
            <div style={css(`width:40px;height:40px;border-radius:10px;background:${u.iconBg};display:flex;align-items:center;justify-content:center;font-size:19px`)}>{u.icon}</div>
            <div style={{ flex: 1 }}><div style={css('font-weight:700;font-size:13px;color:var(--ink)')}>{u.label}</div><div style={css(`font-size:11.5px;color:${u.subColor};font-weight:600;margin-top:1px`)}>{u.sub}</div></div>
            <div>{u.check}</div>
          </div>
        ))}
        <div><div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.mobileNumber}</div><input placeholder="+20 1XX XXX XXXX" style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
        <div><div style={css('font-size:12px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.supportNumber}</div><input placeholder={v.L.supportPh} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} /></div>
      </div>
      <div onClick={v.submitReview} style={css('margin-top:20px;background:#1E63FF;color:#fff;border-radius:14px;padding:16px;text-align:center;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 10px 22px -8px rgba(30,99,255,.6)')}>{v.L.submitReview}</div>
    </div>
  )
}

export function Review() {
  const v = useVals()
  if (!v.isReview) return null
  return (
    <div style={css('animation:fadein .3s ease;padding:40px 28px;text-align:center;min-height:640px;display:flex;flex-direction:column')}>
      <div style={css('margin:30px auto 0;width:110px;height:110px;border-radius:50%;background:rgba(245,166,35,.14);display:flex;align-items:center;justify-content:center;animation:floaty 3s ease-in-out infinite')}>
        <div style={{ fontSize: '52px' }}>📋</div>
      </div>
      <div style={css('font-weight:800;font-size:23px;color:var(--ink);margin-top:24px;letter-spacing:-.4px')}>{v.L.reviewTitle}</div>
      <div style={css('font-size:13.5px;color:var(--soft);margin-top:8px;font-weight:500;line-height:1.6')}>{v.L.reviewBody}</div>
      <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin-top:24px;text-align:start;display:flex;gap:11px;align-items:flex-start')}>
        <div style={{ fontSize: '18px' }}>💡</div>
        <div style={css('font-size:12px;color:var(--soft);font-weight:500;line-height:1.5')}>{v.L.reviewNote}</div>
      </div>
      <div onClick={v.simulateApprove} style={css('margin-top:auto;background:#16B364;color:#fff;border-radius:14px;padding:16px;font-weight:800;font-size:15px;cursor:pointer')}>{v.L.simulateApprove}</div>
      <div onClick={v.enterLimited} style={css('margin-top:11px;font-size:13px;color:#1E63FF;font-weight:700;cursor:pointer')}>{v.L.continueLimited}</div>
    </div>
  )
}
