import { useVals } from '../state/AppContext'
import { css } from '../lib/css'
import { BackArrow } from '../components/ui'

export function Home() {
  const v = useVals()
  if (!v.isHome) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('background:linear-gradient(155deg,#1E63FF,#1546C0);padding:2px 20px 24px;color:#fff;border-radius:0 0 26px 26px')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between')}>
          <div>
            <div style={css('font-size:12.5px;color:rgba(255,255,255,.8);font-weight:500')}>{v.greeting}</div>
            <div style={css('font-weight:800;font-size:20px;letter-spacing:-.3px;margin-top:2px')}>{v.L.userName} 👋</div>
          </div>
          <div style={css('display:flex;gap:8px;align-items:center')}>
            <div onClick={v.toggleLang} style={css('height:34px;padding:0 12px;border-radius:30px;background:rgba(255,255,255,.16);display:flex;align-items:center;font-size:12.5px;font-weight:800;cursor:pointer')}>{v.langLabel}</div>
            <div onClick={v.goCustNotifs} style={css('width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.16);display:flex;align-items:center;justify-content:center;position:relative;cursor:pointer')}><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" /></svg><span style={css('position:absolute;top:7px;right:7px;width:7px;height:7px;background:#F5A623;border-radius:50%;border:1.5px solid #1546C0')} /></div>
          </div>
        </div>
        <div style={css('margin-top:16px;background:rgba(255,255,255,.14);border-radius:16px;padding:15px;display:flex;align-items:center;justify-content:space-between')}>
          <div><div style={css('font-size:11.5px;color:rgba(255,255,255,.82);font-weight:600')}>{v.L.walletBalance}</div><div style={css('font-weight:800;font-size:22px;margin-top:2px')}>{v.walletBal}</div></div>
          <div onClick={v.goSearch} style={css('background:#fff;color:#1546C0;padding:11px 18px;border-radius:30px;font-weight:800;font-size:13px;cursor:pointer')}>＋ {v.L.quickBook}</div>
        </div>
        <div style={css('margin-top:12px;background:#fff;border-radius:14px;padding:12px 15px;display:flex;align-items:center;gap:10px;cursor:pointer')} onClick={v.goSearch}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#1E63FF" strokeWidth="2" /><path d="M16.5 16.5L21 21" stroke="#1E63FF" strokeWidth="2" strokeLinecap="round" /></svg>
          <span style={css('color:#8A93A3;font-size:13.5px;font-weight:500')}>{v.L.searchPh}</span>
        </div>
      </div>

      <div style={css('padding:18px 20px 0')}>
        <div style={css('display:flex;justify-content:space-between;align-items:center;margin-bottom:10px')}><div style={css('font-weight:800;font-size:15px;color:var(--ink)')}>{v.L.upcoming}</div><span onClick={v.goBookings} style={css('font-size:12px;font-weight:700;color:#1E63FF;cursor:pointer')}>{v.L.viewAll}</span></div>
        {v.hasUpcoming && (
          <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px')}>
            <div style={css('display:flex;justify-content:space-between;align-items:flex-start')}>
              <div style={css('display:flex;gap:11px;align-items:center')}><div style={css(`width:44px;height:44px;border-radius:11px;background:${v.up.grad};color:#fff;font-weight:800;font-size:19px;display:flex;align-items:center;justify-content:center`)}>{v.up.mono}</div><div><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{v.up.name}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:1px')}>{v.up.service}</div></div></div>
              <span style={css('background:rgba(30,99,255,.1);color:#1546C0;padding:5px 10px;border-radius:30px;font-size:10.5px;font-weight:800')}>{v.L.upcomingBadge}</span>
            </div>
            <div style={css('display:flex;align-items:center;gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid var(--line2);font-size:12px;color:var(--soft);font-weight:600')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="#1E63FF" strokeWidth="2" /><path d="M12 7v5l3 2" stroke="#1E63FF" strokeWidth="2" strokeLinecap="round" /></svg>{v.up.datetime}
            </div>
          </div>
        )}
      </div>

      <div style={css('padding:20px 20px 0')}>
        <div style={css('font-weight:800;font-size:15px;color:var(--ink);margin-bottom:11px')}>{v.L.services}</div>
        <div style={css('display:flex;gap:10px')}>
          {v.serviceTiles.map((s, i) => (<div key={i} style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 6px;text-align:center')}><div style={{ fontSize: '24px' }}>{s.emoji}</div><div style={css('font-size:10.5px;font-weight:700;color:var(--ink);margin-top:6px')}>{s.label}</div></div>))}
        </div>
      </div>

      <div style={css('padding:20px 20px 16px')}>
        <div style={css('display:flex;justify-content:space-between;align-items:center;margin-bottom:11px')}><div style={css('font-weight:800;font-size:15px;color:var(--ink)')}>{v.L.topRated}</div><span onClick={v.goSearch} style={css('font-size:12px;font-weight:700;color:#1E63FF;cursor:pointer')}>{v.L.viewAll}</span></div>
        <div style={css('display:flex;flex-direction:column;gap:12px')}>
          {v.companiesTop.map((c, i) => (
            <div key={i} onClick={c.onOpen} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:12px;display:flex;gap:12px;align-items:center;cursor:pointer')}>
              <div style={css(`width:52px;height:52px;border-radius:13px;background:${c.grad};color:#fff;font-weight:800;font-size:22px;display:flex;align-items:center;justify-content:center;flex:none`)}>{c.mono}</div>
              <div style={css('flex:1;min-width:0')}><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{c.name}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:2px')}>{c.tag}</div><div style={css('font-size:11px;color:#B9770E;font-weight:700;margin-top:5px')}>⭐ {c.rating} · {c.dist} {v.L.km}</div></div>
              <div style={css('text-align:end')}><div style={css('font-weight:800;font-size:13.5px;color:var(--ink)')}>{c.priceLabel}</div><div style={css('font-size:10.5px;color:var(--muted);font-weight:600')}>{v.L.perHour}</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function Search() {
  const v = useVals()
  if (!v.isSearch) return null
  return (
    <div style={css('animation:fadein .25s ease;padding:8px 20px 20px')}>
      <div style={css('font-weight:800;font-size:20px;color:var(--ink)')}>{v.L.searchTitle}</div>
      <div style={css('margin-top:14px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 15px;display:flex;align-items:center;gap:10px')}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#1E63FF" strokeWidth="2" /><path d="M16.5 16.5L21 21" stroke="#1E63FF" strokeWidth="2" strokeLinecap="round" /></svg>
        <input value={v.searchQuery} onChange={v.onSearch} placeholder={v.L.searchPh} style={css('flex:1;border:none;background:none;font-size:14px;color:var(--ink);outline:none')} />
      </div>
      <div style={css('display:flex;gap:8px;margin-top:14px;overflow-x:auto;padding-bottom:2px')}>
        {v.filters.map((f, i) => (<span key={i} onClick={f.onSelect} style={css(f.style)}>{f.label}</span>))}
      </div>
      <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:18px')}>{v.resultsLabel}</div>
      <div style={css('display:flex;flex-direction:column;gap:12px;margin-top:12px')}>
        {v.companies.map((c, i) => (
          <div key={i} onClick={c.onOpen} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden;cursor:pointer')}>
            <div style={css('display:flex;gap:12px;padding:12px')}>
              <div style={css(`width:70px;height:70px;border-radius:12px;background:${c.grad};flex:none;position:relative;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:26px`)}>{c.mono}<span style={css('position:absolute;bottom:5px;left:5px;background:rgba(0,0,0,.4);color:#fff;padding:2px 6px;font-size:9.5px;font-weight:700;border-radius:30px')}>⭐ {c.rating}</span></div>
              <div style={css('flex:1;min-width:0')}>
                <div style={css('display:flex;justify-content:space-between;align-items:flex-start;gap:6px')}><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{c.name}</div><span style={css('font-size:11px;color:var(--muted);font-weight:600;white-space:nowrap')}>{c.dist} {v.L.km}</span></div>
                <div style={css('color:var(--soft);font-size:11.5px;margin-top:2px;font-weight:500')}>{c.tag}</div>
                <div style={css('display:flex;gap:5px;margin-top:8px;flex-wrap:wrap')}>{c.tags.map((tg, j) => (<span key={j} style={css(tg.style)}>{tg.label}</span>))}</div>
              </div>
            </div>
            <div style={css('display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:var(--field);border-top:1px solid var(--line2)')}><span style={css('font-size:12px;color:var(--muted);font-weight:600')}>{v.L.from} <b style={css('color:var(--ink);font-size:14px')}>{c.priceLabel}</b> {v.L.perHour}</span><span style={css('background:#1E63FF;color:#fff;padding:7px 15px;font-size:12px;font-weight:700;border-radius:30px')}>{v.L.bookNow}</span></div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function Vendor() {
  const v = useVals()
  if (!v.isVendor) return null
  const co = v.co
  return (
    <div style={css('animation:fadein .25s ease;padding-bottom:12px')}>
      <div style={css(`background:${co.grad};padding:0 20px 26px;color:#fff;position:relative;border-radius:0 0 26px 26px`)}>
        <div style={css('display:flex;align-items:center;justify-content:space-between;padding-top:4px')}>
          <div onClick={v.goSearch} style={css('width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="#fff" flip={v.backFlip} /></div>
          <div style={css('width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center')}><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M12 21s-7-4.5-9.5-9C1 8.5 3 5 6.5 5 9 5 12 8 12 8s3-3 5.5-3C21 5 23 8.5 21.5 12 19 16.5 12 21 12 21z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" /></svg></div>
        </div>
        <div style={css('text-align:center;margin-top:6px')}>
          <div style={{ fontSize: '46px' }}>{co.hero}</div>
          <div style={css('width:64px;height:64px;border-radius:18px;background:#fff;color:#1546C0;font-weight:800;font-size:28px;display:flex;align-items:center;justify-content:center;margin:6px auto 0;box-shadow:0 8px 20px -6px rgba(0,0,0,.3)')}>{co.mono}</div>
          <div style={css('font-weight:800;font-size:21px;margin-top:10px')}>{co.name}</div>
          <div style={css('font-size:12.5px;color:rgba(255,255,255,.85);margin-top:3px;font-weight:500')}>{co.tag}</div>
          <div style={css('display:inline-flex;align-items:center;gap:5px;margin-top:9px;background:rgba(255,255,255,.18);padding:5px 12px;border-radius:30px;font-size:12px;font-weight:700')}>⭐ {co.rating} · {co.reviews} {v.L.reviews}</div>
        </div>
      </div>
      <div style={css('padding:16px 20px 0')}>
        <div style={css('display:flex;gap:10px')}>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 8px;text-align:center')}><div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>6 {v.L.yrs}</div><div style={css('font-size:10.5px;color:var(--muted);font-weight:600;margin-top:2px')}>{v.L.experience}</div></div>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 8px;text-align:center')}><div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{co.priceLabel}</div><div style={css('font-size:10.5px;color:var(--muted);font-weight:600;margin-top:2px')}>{v.L.fromPrice}</div></div>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 8px;text-align:center')}><div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{co.dist}</div><div style={css('font-size:10.5px;color:var(--muted);font-weight:600;margin-top:2px')}>{v.L.km}</div></div>
        </div>
        <div style={css('margin-top:16px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 14px;display:flex;align-items:center;gap:11px')}>
          <div style={css('width:40px;height:40px;border-radius:10px;background:rgba(30,99,255,.1);display:flex;align-items:center;justify-content:center')}><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z" stroke="#1E63FF" strokeWidth="2" /><circle cx="12" cy="9" r="2.4" fill="#1E63FF" /></svg></div>
          <div><div style={css('font-weight:700;font-size:13px;color:var(--ink)')}>{v.L.coverage}</div><div style={css('font-size:12px;color:var(--soft);margin-top:1px;font-weight:500')}>{co.coverage}</div></div>
        </div>
        <div style={css('margin-top:18px;font-weight:800;font-size:14px;color:var(--ink)')}>{v.L.services}</div>
        <div style={css('display:flex;gap:8px;flex-wrap:wrap;margin-top:10px')}>{co.services.map((sv, i) => (<span key={i} style={css('background:var(--field);border:1px solid var(--line);color:var(--soft);padding:8px 13px;font-size:12px;font-weight:600;border-radius:30px')}>{sv}</span>))}</div>
        <div style={css('margin-top:18px;font-weight:800;font-size:14px;color:var(--ink)')}>{v.L.gallery}</div>
        <div style={css('display:flex;gap:10px;margin-top:10px;overflow-x:auto;padding-bottom:4px')}>{co.gallery.map((g, i) => (<div key={i} style={css(`width:120px;height:96px;border-radius:14px;flex:none;background:${g.bg};display:flex;align-items:center;justify-content:center;font-size:34px`)}>{g.emoji}</div>))}</div>
      </div>
    </div>
  )
}

export function Config() {
  const v = useVals()
  if (!v.isConfig) return null
  return (
    <div style={css('animation:fadein .2s ease')}>
      <div style={css('padding:6px 20px 14px;background:var(--card);border-bottom:1px solid var(--line)')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between')}>
          <div onClick={v.goVendor} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div>
          <div style={css('font-weight:700;font-size:12.5px;color:var(--soft)')}>{v.L.step} 1/2</div>
          <div style={{ width: '36px' }} />
        </div>
        <div style={css('height:6px;background:var(--line);border-radius:30px;margin-top:12px;overflow:hidden')}><div style={css('height:100%;width:50%;background:linear-gradient(90deg,#1E63FF,#1546C0);border-radius:30px')} /></div>
      </div>
      <div style={css('padding:18px 20px 12px')}>
        <div style={css('font-weight:800;font-size:21px;color:var(--ink);letter-spacing:-.4px')}>{v.L.configTitle}</div>
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:18px;margin-bottom:10px')}>{v.L.cleaningType}</div>
        <div style={css('display:flex;gap:9px;overflow-x:auto;padding-bottom:4px')}>
          {v.cleaningTypes.map((o, i) => (<div key={i} onClick={o.onSelect} style={css(`${o.chipStyle};flex:none;border-radius:14px;padding:12px 14px;cursor:pointer;min-width:96px`)}><div style={{ fontSize: '22px' }}>{o.emoji}</div><div style={css(`font-weight:700;font-size:12.5px;color:${o.titleColor};margin-top:6px`)}>{o.label}</div><div style={css('font-size:11px;color:var(--muted);font-weight:600;margin-top:2px')}>{o.priceLabel}</div></div>))}
        </div>
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:18px;margin-bottom:10px')}>{v.L.propertyType}</div>
        <div onClick={v.openProp} style={css('background:var(--card);border:1.5px solid var(--line);border-radius:14px;padding:14px;display:flex;align-items:center;gap:12px;cursor:pointer')}>
          <span style={{ fontSize: '22px' }}>{v.propEmoji}</span>
          <div style={{ flex: 1 }}><div style={css('font-weight:700;font-size:14px;color:var(--ink)')}>{v.propLabel}</div><div style={css('font-size:11px;color:var(--muted);font-weight:600;margin-top:1px')}>{v.chooseWord}</div></div>
          <span style={css(v.propMultStyle)}>{v.propMultLabel}</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="var(--muted)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </div>
        <div style={css('display:flex;gap:11px;margin-top:16px')}>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;text-align:center')}>
            <div style={css('font-size:11.5px;color:var(--soft);font-weight:700')}>{v.L.hours}</div>
            <div style={css('display:flex;align-items:center;justify-content:center;gap:14px;margin-top:8px')}>
              <div onClick={v.hoursDec} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:var(--ink);cursor:pointer')}>−</div>
              <div style={css('font-weight:800;font-size:22px;color:var(--ink);min-width:24px')}>{v.booking.hours}</div>
              <div onClick={v.hoursInc} style={css('width:36px;height:36px;border-radius:50%;background:#1E63FF;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:#fff;cursor:pointer')}>+</div>
            </div>
          </div>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;text-align:center')}>
            <div style={css('font-size:11.5px;color:var(--soft);font-weight:700')}>{v.L.cleanersUnit}</div>
            <div style={css('display:flex;align-items:center;justify-content:center;gap:14px;margin-top:8px')}>
              <div onClick={v.cleanersDec} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:var(--ink);cursor:pointer')}>−</div>
              <div style={css('font-weight:800;font-size:22px;color:var(--ink);min-width:24px')}>{v.booking.cleaners}</div>
              <div onClick={v.cleanersInc} style={css('width:36px;height:36px;border-radius:50%;background:#1E63FF;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:#fff;cursor:pointer')}>+</div>
            </div>
          </div>
        </div>
        <div onClick={v.toggleSupplies} style={css(`margin-top:12px;background:var(--card);border:1.5px solid ${v.suppliesBorder};border-radius:16px;padding:14px 15px;display:flex;align-items:center;gap:12px;cursor:pointer`)}>
          <div style={{ fontSize: '24px' }}>🧴</div>
          <div style={{ flex: 1 }}><div style={css('font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.suppliesQ}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:600;margin-top:1px')}>+ {v.suppliesPrice}</div></div>
          <div style={css(`width:44px;height:26px;border-radius:30px;background:${v.suppliesTrack};position:relative;transition:background .2s`)}><div style={css(`position:absolute;top:3px;${v.suppliesKnob}:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:all .2s`)} /></div>
        </div>
      </div>
    </div>
  )
}

export function Schedule() {
  const v = useVals()
  if (!v.isSchedule) return null
  return (
    <div style={css('animation:fadein .2s ease')}>
      <div style={css('padding:6px 20px 14px;background:var(--card);border-bottom:1px solid var(--line)')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between')}>
          <div onClick={v.goConfig} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div>
          <div style={css('font-weight:700;font-size:12.5px;color:var(--soft)')}>{v.L.step} 2/2</div>
          <div style={{ width: '36px' }} />
        </div>
        <div style={css('height:6px;background:var(--line);border-radius:30px;margin-top:12px;overflow:hidden')}><div style={css('height:100%;width:100%;background:linear-gradient(90deg,#1E63FF,#1546C0);border-radius:30px')} /></div>
      </div>
      <div style={css('padding:18px 20px 12px')}>
        <div style={css('font-weight:800;font-size:21px;color:var(--ink);letter-spacing:-.4px')}>{v.L.scheduleTitle}</div>
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:16px;margin-bottom:10px')}>{v.L.pickDate}</div>
        <div style={css('display:flex;gap:9px;overflow-x:auto;padding-bottom:6px')}>
          {v.dates.map((d, i) => (<div key={i} onClick={d.onSelect} style={css(`${d.cardStyle};flex:none;width:58px;border-radius:14px;padding:12px 6px;text-align:center;cursor:pointer`)}><div style={css(`font-size:10.5px;font-weight:700;color:${d.subColor}`)}>{d.dow}</div><div style={css(`font-weight:800;font-size:19px;margin-top:3px;color:${d.numColor}`)}>{d.day}</div><div style={css(`font-size:9.5px;font-weight:600;color:${d.subColor};margin-top:2px`)}>{d.mon}</div></div>))}
        </div>
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:16px;margin-bottom:10px')}>{v.L.pickTime}</div>
        <div style={css('display:grid;grid-template-columns:1fr 1fr 1fr;gap:9px')}>
          {v.times.map((tm, i) => (<div key={i} onClick={tm.onSelect} style={css(`${tm.cardStyle};border-radius:12px;padding:13px 6px;text-align:center;font-weight:700;font-size:13px;color:${tm.color};cursor:pointer`)}>{tm.label}</div>))}
        </div>
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:16px;margin-bottom:10px')}>{v.L.addr}</div>
        <div onClick={v.useLocation} style={css('display:flex;align-items:center;gap:9px;background:rgba(30,99,255,.08);border:1px solid rgba(30,99,255,.25);border-radius:14px;padding:12px 14px;cursor:pointer')}><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3.5" stroke="#1E63FF" strokeWidth="2" /><path d="M12 2v3M12 19v3M22 12h-3M5 12H2" stroke="#1E63FF" strokeWidth="2" strokeLinecap="round" /></svg><span style={css('font-weight:700;font-size:12.5px;color:#1E63FF')}>{v.L.useLocation}</span></div>
        <div style={css('margin-top:11px;height:104px;border-radius:14px;border:1px solid var(--line);overflow:hidden;position:relative;background:linear-gradient(135deg,#dfe8f5,#eef3fa)')}><div style={css('position:absolute;inset:0;background-image:linear-gradient(rgba(30,99,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(30,99,255,.08) 1px,transparent 1px);background-size:24px 24px')} /><div style={css('position:absolute;left:50%;top:46%;transform:translate(-50%,-100%);font-size:28px')}>📍</div><div style={css('position:absolute;bottom:8px;left:8px;background:rgba(255,255,255,.9);padding:4px 9px;border-radius:8px;font-size:10.5px;font-weight:700;color:#1546C0')}>{v.L.mapsPlaceholder}</div></div>
        <input value={v.booking.address} onChange={v.onAddress} placeholder={v.L.addressPh} style={css('width:100%;margin-top:11px;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} />
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:16px;margin-bottom:10px')}>{v.L.notesK}</div>
        <div style={css('display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px')}>{v.instrChips.map((ic, i) => (<span key={i} onClick={ic.onToggle} style={css(`${ic.style};cursor:pointer`)}>{ic.label}</span>))}</div>
        <textarea value={v.booking.notes} onChange={v.onNotes} placeholder={v.L.notesPh} style={css('width:100%;height:72px;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:13px;font-size:14px;color:var(--ink);outline:none;resize:none')} />
      </div>
    </div>
  )
}
