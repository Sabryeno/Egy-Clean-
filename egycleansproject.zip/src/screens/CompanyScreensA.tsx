import { useVals } from '../state/AppContext'
import { css } from '../lib/css'

export function CHome() {
  const v = useVals()
  if (!v.isCHome) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('background:linear-gradient(155deg,#0E1726,#1E293F);padding:2px 20px 22px;color:#fff;border-radius:0 0 26px 26px')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between')}>
          <div><div style={css('font-size:12px;color:rgba(255,255,255,.7);font-weight:500')}>{v.greeting}</div><div style={css('font-weight:800;font-size:19px;margin-top:2px')}>{v.co.name}</div></div>
          <div style={css('display:flex;gap:8px;align-items:center')}><div onClick={v.toggleLang} style={css('height:34px;padding:0 12px;border-radius:30px;background:rgba(255,255,255,.14);display:flex;align-items:center;font-size:12.5px;font-weight:800;cursor:pointer')}>{v.langLabel}</div><div onClick={v.goCNotifs} style={css('width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.14);display:flex;align-items:center;justify-content:center;position:relative')}><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" /></svg><span style={css('position:absolute;top:6px;right:6px;width:8px;height:8px;background:#F5A623;border-radius:50%;border:1.5px solid #16233c')} /></div></div>
        </div>
        {v.notApproved && (
          <div style={css('margin-top:14px;background:rgba(245,166,35,.16);border:1px solid rgba(245,166,35,.4);border-radius:14px;padding:12px 14px;display:flex;gap:10px;align-items:center')}><span style={{ fontSize: '18px' }}>⏳</span><div style={{ flex: 1 }}><div style={css('font-weight:800;font-size:12.5px;color:#F5A623')}>{v.L.reviewTitle}</div><div style={css('font-size:11px;color:rgba(255,255,255,.75);font-weight:500;margin-top:1px')}>{v.L.limitedNote}</div></div></div>
        )}
        <div style={css('display:flex;gap:10px;margin-top:14px')}>
          <div style={css('flex:1;background:rgba(255,255,255,.1);border-radius:14px;padding:13px')}><div style={css('font-size:11px;color:rgba(255,255,255,.7);font-weight:600')}>{v.L.todayBookings}</div><div style={css('font-weight:800;font-size:22px;margin-top:3px')}>{v.statToday}</div></div>
          <div style={css('flex:1;background:rgba(255,255,255,.1);border-radius:14px;padding:13px')}><div style={css('font-size:11px;color:rgba(255,255,255,.7);font-weight:600')}>{v.L.earnings}</div><div style={css('font-weight:800;font-size:22px;margin-top:3px')}>{v.statEarnings}</div></div>
        </div>
      </div>
      <div style={css('padding:18px 20px 0')}>
        <div style={css('font-weight:800;font-size:15px;color:var(--ink);margin-bottom:12px')}>{v.analyticsTitle}</div>
        <div style={css('display:flex;gap:10px')}>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px;text-align:center')}><div style={css('font-weight:800;font-size:18px;color:var(--ink)')}>{v.statMonthJobs}</div><div style={css('font-size:10px;color:var(--muted);font-weight:600;margin-top:2px')}>{v.statJobsLabel}</div></div>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px;text-align:center')}><div style={css('font-weight:800;font-size:18px;color:#16B364')}>{v.statPaidPct}</div><div style={css('font-size:10px;color:var(--muted);font-weight:600;margin-top:2px')}>{v.statPaidLabel}</div></div>
          <div style={css('flex:1;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px;text-align:center')}><div style={css('font-weight:800;font-size:18px;color:#B9770E')}>⭐ {v.statRating}</div><div style={css('font-size:10px;color:var(--muted);font-weight:600;margin-top:2px')}>{v.statRatingLabel}</div></div>
        </div>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px;margin-top:12px')}>
          <div style={css('display:flex;justify-content:space-between;align-items:center')}><div style={css('font-weight:800;font-size:12.5px;color:var(--ink)')}>{v.chartTitle}</div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.chartMaxLabel}</div></div>
          <div style={css('display:flex;align-items:flex-end;gap:8px;height:88px;margin-top:14px')}>{v.chartBars.map((c, i) => (<div key={i} style={css('flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end')}><div style={css(`width:100%;height:${c.h};background:${c.fill};border-radius:6px;min-height:6px;transition:height .3s`)} /><div style={css('font-size:9.5px;color:var(--muted);font-weight:700')}>{c.d}</div></div>))}</div>
        </div>
        <div style={css('display:flex;align-items:center;justify-content:space-between;margin-top:16px')}><div style={css('font-weight:800;font-size:12px;color:var(--soft)')}>{v.filterWord}</div><div onClick={v.openFilter} style={css('display:flex;align-items:center;gap:7px;background:var(--card);border:1px solid var(--line);border-radius:30px;padding:8px 14px;cursor:pointer')}><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M3 5h18M6 12h12M10 19h4" stroke="#1E63FF" strokeWidth="2" strokeLinecap="round" /></svg><span style={css('font-weight:800;font-size:12px;color:var(--ink)')}>{v.filterSummary}</span>{v.filterActive && (<span style={css('width:7px;height:7px;border-radius:50%;background:#1E63FF')} />)}</div></div>
      </div>
      <div style={css('padding:18px 20px 16px')}>
        <div style={css('display:flex;justify-content:space-between;align-items:center;margin-bottom:12px')}><div style={css('font-weight:800;font-size:15px;color:var(--ink)')}>{v.L.incoming}</div>{v.hasPending && (<span style={css('background:rgba(245,166,35,.15);color:#B9770E;padding:4px 10px;border-radius:30px;font-size:11px;font-weight:800')}>{v.pendingCount} {v.L.pending}</span>)}</div>
        <div style={css('display:flex;flex-direction:column;gap:12px')}>
          {v.incomingList.map((j, i) => (
            <div key={i} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px')}>
              <div style={css('display:flex;justify-content:space-between;align-items:flex-start')}><div><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{j.customer}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:2px')}>{j.service} · {j.datetime}</div></div><span style={css(j.methodStyle)}>{j.methodLabel}</span></div>
              <div style={css('display:flex;justify-content:space-between;align-items:center;margin-top:12px;padding-top:12px;border-top:1px solid var(--line2)')}>
                <div style={css('font-weight:800;font-size:16px;color:var(--ink)')}>{j.total}</div>
                <div>{j.action}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function CServices() {
  const v = useVals()
  if (!v.isCServices) return null
  return (
    <div style={css('animation:fadein .25s ease;padding:14px 20px 24px')}>
      <div style={css('display:flex;align-items:center;justify-content:space-between')}><div style={css('font-weight:800;font-size:20px;color:var(--ink)')}>{v.L.manageServices}</div><div onClick={v.addService} style={css('background:#1E63FF;color:#fff;padding:9px 15px;border-radius:30px;font-weight:800;font-size:12.5px;cursor:pointer')}>＋ {v.L.addService}</div></div>
      <div style={css('font-size:12.5px;color:var(--soft);font-weight:500;margin-top:6px')}>{v.L.servicesSub}</div>
      <div style={css('display:flex;flex-direction:column;gap:12px;margin-top:16px')}>
        {v.cServices.map((s, i) => (
          <div key={i} onClick={s.onEdit} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px;cursor:pointer')}>
            <div style={css('display:flex;align-items:center;gap:11px')}><div style={css(`width:44px;height:44px;border-radius:12px;background:${s.iconBg};display:flex;align-items:center;justify-content:center;font-size:22px`)}>{s.emoji}</div><div style={{ flex: 1 }}><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{s.name}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:1px')}>{s.desc}</div></div><div style={css('text-align:end')}><div style={css('font-weight:800;font-size:15px;color:#1E63FF')}>{s.rate}</div><div style={css('font-size:10px;color:var(--muted);font-weight:600')}>{v.L.perHour}</div></div></div>
            <div style={css('display:flex;gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid var(--line2);align-items:center')}><span style={css('background:var(--field);color:var(--soft);padding:5px 10px;border-radius:30px;font-size:10.5px;font-weight:700')}>👷 {s.cleaners}</span><span style={css('background:var(--field);color:var(--soft);padding:5px 10px;border-radius:30px;font-size:10.5px;font-weight:700')}>📦 {s.capacity}</span><span style={css('margin-inline-start:auto;color:#1E63FF;font-size:11px;font-weight:800')}>{v.editWord}</span></div>
          </div>
        ))}
      </div>
      <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:22px;margin-bottom:10px')}>{v.L.areaCovered}</div>
      <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px')}>
        <div style={css('height:100px;border-radius:12px;overflow:hidden;position:relative;background:linear-gradient(135deg,#dfe8f5,#eef3fa)')}><div style={css('position:absolute;inset:0;background-image:linear-gradient(rgba(30,99,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(30,99,255,.08) 1px,transparent 1px);background-size:22px 22px')} /><div style={css('position:absolute;left:44%;top:44%;width:70px;height:70px;border-radius:50%;background:rgba(30,99,255,.18);border:2px solid #1E63FF;transform:translate(-50%,-50%)')} /><div style={css('position:absolute;left:44%;top:40%;transform:translate(-50%,-100%);font-size:24px')}>📍</div></div>
        <div style={css('display:flex;gap:8px;flex-wrap:wrap;margin-top:12px')}>{v.coverageAreas.map((a, i) => (<span key={i} style={css('background:rgba(30,99,255,.1);color:#1546C0;padding:6px 11px;border-radius:30px;font-size:11.5px;font-weight:700')}>{a}</span>))}</div>
      </div>
    </div>
  )
}

export function CHistory() {
  const v = useVals()
  if (!v.isCHistory) return null
  return (
    <div style={css('animation:fadein .25s ease')}>
      <div style={css('padding:14px 20px 0;background:var(--card);border-bottom:1px solid var(--line)')}>
        <div style={css('font-weight:800;font-size:19px;color:var(--ink)')}>{v.L.customerHistory}</div>
        <div style={css('display:flex;gap:20px;margin-top:14px')}><div onClick={v.tabUpcoming} style={css(v.tabUpStyle)}>{v.L.upcoming}</div><div onClick={v.tabPast} style={css(v.tabPastStyle)}>{v.L.past}</div></div>
      </div>
      <div style={css('padding:16px 20px;display:flex;flex-direction:column;gap:13px')}>
        {v.cHistoryList.map((b, i) => (
          <div key={i} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px')}>
            <div style={css('display:flex;justify-content:space-between;align-items:flex-start')}><div><div style={css('font-weight:800;font-size:14.5px;color:var(--ink)')}>{b.customer}</div><div style={css('font-size:11.5px;color:var(--soft);font-weight:500;margin-top:2px')}>{b.service}</div></div><span style={css(b.badgeStyle)}>{b.badge}</span></div>
            <div style={css('margin-top:10px')}><span style={css(b.payStyle)}>{b.payLabel}</span></div><div style={css('display:flex;justify-content:space-between;align-items:center;margin-top:11px;padding-top:12px;border-top:1px solid var(--line2)')}><div style={css('font-size:11.5px;color:var(--soft);font-weight:600')}>{b.datetime}</div><div style={css('font-weight:800;font-size:15px;color:var(--ink)')}>{b.total}</div></div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function CNotifs() {
  const v = useVals()
  if (!v.isCNotifs) return null
  return (
    <div style={css('animation:fadein .25s ease;padding:14px 20px 24px')}>
      <div style={css('font-weight:800;font-size:20px;color:var(--ink)')}>{v.L.notifications}</div>
      <div style={css('display:flex;flex-direction:column;gap:12px;margin-top:16px')}>
        {v.notifList.map((n, i) => (
          <div key={i} style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px')}>
            <div style={css('display:flex;gap:12px')}><div style={css(`width:40px;height:40px;border-radius:11px;background:${n.iconBg};display:flex;align-items:center;justify-content:center;font-size:19px;flex:none`)}>{n.icon}</div>
              <div style={{ flex: 1 }}><div style={css('font-weight:800;font-size:13.5px;color:var(--ink)')}>{n.title}</div><div style={css('font-size:12px;color:var(--soft);font-weight:500;margin-top:2px;line-height:1.4')}>{n.body}</div><div style={css('font-size:11px;color:var(--muted);font-weight:600;margin-top:5px')}>{n.time}</div></div></div>
            <div style={css('margin-top:12px')}>{n.action}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
