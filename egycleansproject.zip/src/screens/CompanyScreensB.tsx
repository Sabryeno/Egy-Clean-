import { useVals } from '../state/AppContext'
import { css } from '../lib/css'
import { BackArrow } from '../components/ui'

export function CProfile() {
  const v = useVals()
  if (!v.isCProfile) return null
  return (
    <div style={css('animation:fadein .25s ease;padding-bottom:24px')}>
      <div style={css(`background:${v.co.grad};padding:20px 20px 24px;color:#fff;text-align:center;border-radius:0 0 26px 26px`)}>
        <div style={css('width:70px;height:70px;border-radius:20px;background:#fff;color:#1546C0;font-weight:800;font-size:30px;display:flex;align-items:center;justify-content:center;margin:0 auto')}>{v.co.mono}</div>
        <div style={css('font-weight:800;font-size:20px;margin-top:12px')}>{v.co.name}</div>
        <div style={css('display:inline-flex;align-items:center;gap:6px;margin-top:8px;background:rgba(255,255,255,.18);padding:5px 12px;border-radius:30px;font-size:11.5px;font-weight:700')}>{v.approvalBadge}</div>
      </div>
      <div style={css('padding:16px 20px 0')}>
        <div style={css('display:flex;align-items:center;justify-content:space-between;margin-bottom:10px')}><div style={css('font-weight:800;font-size:13px;color:var(--soft)')}>{v.L.editContacts}</div>{v.notEditingContacts && (<div onClick={v.startEditContacts} style={css('display:flex;align-items:center;gap:5px;background:rgba(30,99,255,.1);color:#1E63FF;padding:6px 12px;border-radius:30px;font-weight:800;font-size:11.5px;cursor:pointer')}><svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M4 20h4L18.5 9.5a2 2 0 000-3l-.99-.99a2 2 0 00-3 0L4 16v4z" stroke="#1E63FF" strokeWidth="2" strokeLinejoin="round" /></svg>{v.editWord2}</div>)}</div>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px;display:flex;flex-direction:column;gap:13px')}>
          {v.editingContacts && (
            <>
              <div><div style={css('font-size:11.5px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.managerContact}</div><input value={v.mgrContact} onChange={v.onMgr} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:12px;padding:13px;font-size:13.5px;color:var(--ink);outline:none')} /></div>
              <div><div style={css('font-size:11.5px;font-weight:700;color:var(--soft);margin-bottom:6px')}>{v.L.supportContact}</div><input value={v.supContact} onChange={v.onSup} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:12px;padding:13px;font-size:13.5px;color:var(--ink);outline:none')} /></div>
              <div onClick={v.saveContacts} style={css('background:#1E63FF;color:#fff;border-radius:12px;padding:13px;text-align:center;font-weight:800;font-size:13.5px;cursor:pointer')}>{v.saveLabel}</div>
            </>
          )}
          {v.notEditingContacts && (
            <>
              <div style={css('display:flex;align-items:center;gap:11px')}><div style={css('width:36px;height:36px;border-radius:10px;background:rgba(30,99,255,.1);display:flex;align-items:center;justify-content:center;font-size:16px')}>👤</div><div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.L.managerContact}</div><div style={css('font-weight:700;font-size:13.5px;color:var(--ink);margin-top:1px')}>{v.mgrContact}</div></div></div>
              <div style={css('height:1px;background:var(--line2)')} />
              <div style={css('display:flex;align-items:center;gap:11px')}><div style={css('width:36px;height:36px;border-radius:10px;background:rgba(22,179,100,.12);display:flex;align-items:center;justify-content:center;font-size:16px')}>🎧</div><div><div style={css('font-size:11px;color:var(--muted);font-weight:600')}>{v.L.supportContact}</div><div style={css('font-weight:700;font-size:13.5px;color:var(--ink);margin-top:1px')}>{v.supContact}</div></div></div>
            </>
          )}
        </div>
        <div style={css('font-weight:800;font-size:13px;color:var(--soft);margin-top:22px;margin-bottom:10px')}>{v.L.verifiedDocs}</div>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden')}>
          {v.lockedDocs.map((d, i) => (
            <div key={i} style={css(`display:flex;align-items:center;gap:12px;padding:14px 15px;border-bottom:1px solid var(--line2);${d.expBg}`)}><span style={{ fontSize: '17px' }}>{d.icon}</span><div style={{ flex: 1 }}><div style={css('font-weight:700;font-size:13px;color:var(--ink)')}>{d.label}</div><div style={css('font-size:11px;color:var(--soft);font-weight:500;margin-top:1px')}>{d.value}</div><div style={css(`${d.expStyle};font-size:10.5px;margin-top:3px`)}>{d.expLabel}</div></div><span style={css('display:flex;align-items:center;gap:4px;color:#16B364;font-size:11px;font-weight:700')}><svg width="13" height="13" viewBox="0 0 24 24" fill="none"><rect x="5" y="11" width="14" height="9" rx="2" stroke="#16B364" strokeWidth="2" /><path d="M8 11V8a4 4 0 018 0v3" stroke="#16B364" strokeWidth="2" /></svg>{v.L.locked}</span></div>
          ))}
        </div>
        <div style={css('font-size:11.5px;color:var(--muted);font-weight:500;margin-top:10px;line-height:1.5;text-align:center')}>{v.L.cannotEditDocs}</div>
        <div style={css('display:flex;align-items:center;justify-content:space-between;margin-top:22px;margin-bottom:10px')}><div style={css('font-weight:800;font-size:13px;color:var(--soft)')}>{v.staffTitle}</div><div onClick={v.addStaff} style={css('background:#1E63FF;color:#fff;padding:8px 13px;border-radius:30px;font-weight:800;font-size:11.5px;cursor:pointer')}>＋ {v.addStaffWord}</div></div>
        <div style={css('display:flex;flex-direction:column;gap:10px')}>
          {v.staffList.map((s, i) => (
            <div key={i} style={css('background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px;display:flex;align-items:center;gap:12px')}>
              <div style={css(`width:46px;height:46px;border-radius:50%;background:${s.color};color:#fff;font-weight:800;font-size:19px;display:flex;align-items:center;justify-content:center;flex:none`)}>{s.mono}</div>
              <div style={css('flex:1;min-width:0')}><div style={css('font-weight:800;font-size:13.5px;color:var(--ink)')}>{s.name}</div><div style={css('font-size:11px;color:var(--soft);font-weight:500;margin-top:1px')}>{s.role} · {s.jobs} {v.jobsWord}</div><div style={css('margin-top:4px;font-size:12px;color:#F5A623;font-weight:700')}>{s.stars} <span style={css('color:var(--muted);font-size:10.5px')}>{s.ratingLabel}</span></div></div>
              <div onClick={s.onRemove} style={css('width:30px;height:30px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--muted);font-size:15px')}>✕</div>
            </div>
          ))}
        </div>
        <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;margin-top:18px;overflow:hidden')}>
          <div onClick={v.toggleLang} style={css('display:flex;align-items:center;gap:12px;padding:14px 15px;border-bottom:1px solid var(--line2);cursor:pointer')}><span style={{ fontSize: '17px' }}>🌐</span><span style={css('flex:1;font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.language}</span><span style={css('font-size:12px;font-weight:700;color:#1E63FF')}>{v.langFull}</span></div>
          <div onClick={v.toggleTheme} style={css('display:flex;align-items:center;gap:12px;padding:14px 15px;cursor:pointer')}><span style={{ fontSize: '17px' }}>{v.themeIcon}</span><span style={css('flex:1;font-weight:700;font-size:13.5px;color:var(--ink)')}>{v.L.appearance}</span><span style={css('font-size:12px;font-weight:700;color:#1E63FF')}>{v.themeLabel}</span></div>
        </div>
        <div onClick={v.logout} style={css('margin-top:16px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:15px;text-align:center;font-weight:700;font-size:14px;color:#E5484D;cursor:pointer')}>{v.L.logout}</div>
      </div>
    </div>
  )
}

export function CServiceForm() {
  const v = useVals()
  if (!v.isCServiceForm) return null
  return (
    <div style={css('animation:fadein .2s ease;padding:6px 20px 24px')}>
      <div style={css('display:flex;align-items:center;gap:12px')}><div onClick={v.backToServices} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div><div style={css('font-weight:800;font-size:18px;color:var(--ink)')}>{v.svcFormTitle}</div></div>
      <div style={css('font-weight:800;font-size:12px;color:var(--soft);margin-top:18px;margin-bottom:10px')}>{v.L.cleaningType}</div>
      <div style={css('display:grid;grid-template-columns:1fr 1fr;gap:9px')}>{v.svcTypeOpts.map((o, i) => (<div key={i} onClick={o.onSel} style={css(`${o.style};border-radius:14px;padding:13px;display:flex;align-items:center;gap:9px;cursor:pointer`)}><span style={{ fontSize: '20px' }}>{o.emoji}</span><span style={css(`font-weight:700;font-size:12.5px;color:${o.color}`)}>{o.label}</span></div>))}</div>
      <div style={css('font-weight:800;font-size:12px;color:var(--soft);margin-top:18px;margin-bottom:10px')}>{v.rateWord}</div>
      <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;display:flex;align-items:center;justify-content:center;gap:16px')}><div onClick={v.svcRateDec} style={css('width:40px;height:40px;border-radius:50%;background:var(--field);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;color:var(--ink);cursor:pointer')}>−</div><div style={css('text-align:center;min-width:120px')}><div style={css('font-weight:800;font-size:24px;color:#1E63FF')}>{v.svcRateLabel}</div><div style={css('font-size:10.5px;color:var(--muted);font-weight:600')}>{v.L.perHour}</div></div><div onClick={v.svcRateInc} style={css('width:40px;height:40px;border-radius:50%;background:#1E63FF;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;color:#fff;cursor:pointer')}>+</div></div>
      <div style={css('background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;text-align:center;margin-top:14px')}><div style={css('font-size:11px;color:var(--soft);font-weight:700')}>{v.cleanersWord}</div><div style={css('display:flex;align-items:center;justify-content:center;gap:14px;margin-top:8px')}><div onClick={v.svcCleanersDec} style={css('width:34px;height:34px;border-radius:50%;background:var(--field);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-size:19px;font-weight:700;color:var(--ink);cursor:pointer')}>−</div><div style={css('font-weight:800;font-size:20px;color:var(--ink);min-width:22px')}>{v.svcCleaners}</div><div onClick={v.svcCleanersInc} style={css('width:34px;height:34px;border-radius:50%;background:#1E63FF;display:flex;align-items:center;justify-content:center;font-size:19px;font-weight:700;color:#fff;cursor:pointer')}>+</div></div></div>
      <div style={css('font-weight:800;font-size:12px;color:var(--soft);margin-top:16px;margin-bottom:8px')}>{v.capacityWord}</div>
      <input value={v.svcCapacity} onChange={v.onSvcCapacity} placeholder={v.capacityPh} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} />
      <div onClick={v.saveService} style={css('margin-top:20px;background:#1E63FF;color:#fff;border-radius:14px;padding:16px;text-align:center;font-weight:800;font-size:15px;cursor:pointer')}>{v.saveServiceWord}</div>
      {v.canDeleteSvc && (<div onClick={v.deleteService} style={css('margin-top:12px;text-align:center;font-weight:700;font-size:13px;color:#E5484D;cursor:pointer')}>{v.deleteWord}</div>)}
    </div>
  )
}

export function CStaffForm() {
  const v = useVals()
  if (!v.isCStaffForm) return null
  return (
    <div style={css('animation:fadein .2s ease;padding:6px 20px 24px')}>
      <div style={css('display:flex;align-items:center;gap:12px')}><div onClick={v.backToProfile} style={css('width:36px;height:36px;border-radius:50%;background:var(--field);display:flex;align-items:center;justify-content:center;cursor:pointer')}><BackArrow stroke="var(--ink)" flip={v.backFlip} /></div><div style={css('font-weight:800;font-size:18px;color:var(--ink)')}>{v.addStaffWord}</div></div>
      <div style={css('text-align:center;margin-top:20px')}><div style={css(`width:84px;height:84px;border-radius:50%;background:${v.staffColor};color:#fff;font-weight:800;font-size:34px;display:flex;align-items:center;justify-content:center;margin:0 auto`)}>{v.staffMonoPreview}</div><div style={css('font-size:11.5px;color:var(--muted);font-weight:600;margin-top:8px')}>{v.photoAutoNote}</div></div>
      <div style={css('display:flex;gap:11px;justify-content:center;margin-top:16px')}>{v.staffColorOpts.map((c, i) => (<div key={i} onClick={c.onSel} style={css(`width:28px;height:28px;border-radius:50%;background:${c.c};cursor:pointer;box-shadow:${c.ring}`)} />))}</div>
      <div style={css('font-weight:800;font-size:12px;color:var(--soft);margin-top:22px;margin-bottom:8px')}>{v.staffNameWord}</div>
      <input value={v.staffFormName} onChange={v.onStaffName} placeholder={v.staffNamePh} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} />
      <div style={css('font-weight:800;font-size:12px;color:var(--soft);margin-top:14px;margin-bottom:8px')}>{v.staffRoleWord}</div>
      <input value={v.staffFormRole} onChange={v.onStaffRole} placeholder={v.staffRolePh} style={css('width:100%;background:var(--field);border:1px solid var(--line);border-radius:14px;padding:14px;font-size:14px;color:var(--ink);outline:none')} />
      <div onClick={v.saveStaff} style={css(`margin-top:22px;border-radius:14px;padding:16px;text-align:center;font-weight:800;font-size:15px;cursor:pointer;background:${v.saveStaffBg};color:${v.saveStaffColor}`)}>{v.saveStaffWord}</div>
    </div>
  )
}
