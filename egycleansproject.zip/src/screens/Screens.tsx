import { Splash, Login, Signup, CorpReg, Review } from './AuthScreens'
import { Home, Search, Vendor, Config, Schedule } from './CustomerScreensA'
import { Summary, Payment, Success, Bookings, Account, CustNotifs, CustProfile } from './CustomerScreensB'
import { CHome, CServices, CHistory, CNotifs } from './CompanyScreensA'
import { CProfile, CServiceForm, CStaffForm } from './CompanyScreensB'

export function Screens() {
  return (
    <>
      {/* Auth */}
      <Splash />
      <Login />
      <Signup />
      <CorpReg />
      <Review />
      {/* Customer */}
      <Home />
      <Search />
      <Vendor />
      <Config />
      <Schedule />
      <Summary />
      <Payment />
      <Success />
      <Bookings />
      <Account />
      <CustNotifs />
      <CustProfile />
      {/* Company */}
      <CHome />
      <CServices />
      <CHistory />
      <CNotifs />
      <CProfile />
      <CServiceForm />
      <CStaffForm />
    </>
  )
}
