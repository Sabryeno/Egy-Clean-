import type { CSSProperties } from 'react'

/**
 * Parses a CSS declaration string ("color:red;padding:4px") into a React
 * style object. Lets us port the prototype's inline style strings verbatim,
 * including CSS custom properties (--var) used for theming.
 */
export function css(str: string): CSSProperties {
  const out: Record<string, string> = {}
  if (!str) return out as CSSProperties
  for (const part of str.split(';')) {
    const idx = part.indexOf(':')
    if (idx === -1) continue
    let key = part.slice(0, idx).trim()
    const val = part.slice(idx + 1).trim()
    if (!key) continue
    if (key.startsWith('--')) {
      out[key] = val
      continue
    }
    key = key.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase())
    out[key] = val
  }
  return out as CSSProperties
}
