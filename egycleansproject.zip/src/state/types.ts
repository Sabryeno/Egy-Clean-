import type { Lang } from './i18n'

export type Screen =
  | 'splash' | 'login' | 'signup' | 'corpReg' | 'review'
  | 'home' | 'search' | 'vendor' | 'config' | 'schedule'
  | 'summary' | 'payment' | 'success' | 'bookings' | 'account'
  | 'custNotifs' | 'custProfile'
  | 'cHome' | 'cServices' | 'cHistory' | 'cNotifs' | 'cProfile'
  | 'cServiceForm' | 'cStaffForm'

export type AppMode = 'auth' | 'customer' | 'company'
export type Acct = 'individual' | 'corporate'
export type Theme = 'light' | 'dark'
export type PayMethod = 'card' | 'applepay' | 'gpay' | 'meeza' | 'vodafone' | 'instapay' | 'cash'

export interface CompanyDef {
  mono: string
  grad: string
  name: Record<Lang, string>
  tag: Record<Lang, string>
  rating: string
  reviews: number
  dist: string
  base: number
  tags: string[]
  hero: string
  coverage: Record<Lang, string>
}

export interface Booking {
  mono: string
  grad: string
  name: string
  service: string
  datetime: string
  id: string
  total: string
  status: 'upcoming' | 'past'
  paid: boolean
  method: PayMethod | string
}

export interface IncomingJob {
  customer: string
  service: string
  datetime: string
  total: string
  method: 'cash' | 'paid'
  state: 'pending' | 'new' | 'approved' | 'declined' | 'ack'
  paid: boolean
  payMethod?: PayMethod
  staff: string
  svcIdx: number
  bucket: 'today' | 'week'
}

export interface CustomerHistoryItem {
  customer: string
  service: string
  datetime: string
  total: string
  status: 'upcoming' | 'past'
  paid: boolean
  method: PayMethod | string
  staff: string
  svcIdx: number
}

export interface CServiceItem {
  id: number
  typeIdx: number
  rate: number
  cleaners: number
  capacity: string
}

export interface StaffMember {
  name: string
  mono?: string
  color: string
  rating: number
  jobs: number
  role: string
}

export interface SvcForm {
  editId: number | null
  typeIdx: number
  rate: number
  cleaners: number
  capacity: string
}

export interface StaffForm {
  name: string
  role: string
  color: string
}

export interface AppState {
  screen: Screen
  app: AppMode
  acct: Acct
  corpApproved: boolean
  lang: Lang
  theme: Theme
  co: number
  activeFilter: number
  searchQuery: string
  ctIdx: number
  ptIdx: number
  hours: number
  cleaners: number
  supplies: boolean
  dateIdx: number
  timeIdx: number
  address: string
  notes: string
  instr: number[]
  payIdx: number | null
  agree: boolean
  histTab: 'upcoming' | 'past'
  photo: boolean
  mgr: string
  sup: string
  savedContacts: boolean
  editingContacts: boolean
  filterOpen: boolean
  propOpen: boolean
  pName: string
  pEmail: string
  pPhone: string
  pCity: string
  editingProfile: boolean
  lastId: string
  lastMethod: PayMethod | string
  cServices: CServiceItem[]
  staff: StaffMember[]
  svcForm: SvcForm | null
  staffForm: StaffForm
  dashDate: 'today' | 'week' | 'month'
  dashSvc: string
  dashStaff: string
  bookings: Booking[]
  cIncoming: IncomingJob[]
  cHistory: CustomerHistoryItem[]
  up_lic: boolean
  up_id: boolean
}
