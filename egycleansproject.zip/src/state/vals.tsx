import React from 'react'
import type { AppState, Screen } from './types'
import { T } from './i18n'
import { COMPANIES, RATES, PROP_MULT, TIMES } from './data'
import {
  fmt, tagChip, methodMeta, payIdxKey, payPill, svcEmoji, svcBg, stars,
  price, dateList, chipSel,
} from './helpers'

export interface Api {
  set: <K extends keyof AppState>(k: K, v: AppState[K]) => void
  setState: (partial: Partial<AppState>) => void
  go: (screen: Screen) => void
}

function btn(label: string, bg: string, color: string, onClick: () => void) {
  return (
    <div onClick={onClick} style={{ background: bg, color, padding: '9px 16px', borderRadius: '30px', fontWeight: 800, fontSize: '12.5px', cursor: 'pointer' }}>
      {label}
    </div>
  )
}

export function buildVals(s: AppState, api: Api) {
  const L = T(s.lang), lang = s.lang, ar = lang === 'ar'
  const comps = COMPANIES, co = comps[s.co], p = price(s)
  const dates = dateList(L), times = TIMES, screen = s.screen
  const set = api.set, setState = api.setState, go = api.go

  const updIncoming = (i: number, newState: AppState['cIncoming'][number]['state']) => {
    const arr = s.cIncoming.map((j, idx) => (idx === i ? { ...j, state: newState } : j))
    setState({ cIncoming: arr })
  }
  const setSvc = (k: keyof NonNullable<AppState['svcForm']>, v: any) => {
    if (!s.svcForm) return
    setState({ svcForm: { ...s.svcForm, [k]: v } })
  }
  const saveService = () => {
    const f = s.svcForm
    if (!f) return
    let arr = s.cServices.slice()
    if (f.editId) arr = arr.map((x) => (x.id === f.editId ? { ...x, typeIdx: f.typeIdx, rate: f.rate, cleaners: f.cleaners, capacity: f.capacity || x.capacity } : x))
    else arr.push({ id: Date.now(), typeIdx: f.typeIdx, rate: f.rate, cleaners: f.cleaners, capacity: f.capacity || '—' })
    setState({ cServices: arr, svcForm: null, screen: 'cServices' })
  }
  const deleteService = () => {
    const f = s.svcForm
    if (!f || !f.editId) return
    setState({ cServices: s.cServices.filter((x) => x.id !== f.editId), svcForm: null, screen: 'cServices' })
  }
  const setStaff = (k: keyof AppState['staffForm'], v: string) => setState({ staffForm: { ...s.staffForm, [k]: v } })
  const saveStaff = () => {
    const f = s.staffForm
    if (!f.name.trim()) return
    const arr = s.staff.concat([{ name: f.name.trim(), mono: (f.name.trim()[0] || '?').toUpperCase(), color: f.color, rating: 5.0, jobs: 0, role: f.role || (ar ? 'عامل نظافة' : 'Cleaner') }])
    setState({ staff: arr, staffForm: { name: '', role: '', color: '#1E63FF' }, screen: 'cProfile' })
  }
  const removeStaff = (i: number) => setState({ staff: s.staff.filter((_, idx) => idx !== i) })

  const mkCompany = (c: typeof comps[number], i: number) => ({
    mono: c.mono, grad: c.grad, name: c.name[lang], tag: c.tag[lang], rating: c.rating, reviews: c.reviews, dist: c.dist,
    priceLabel: fmt(lang, c.base), tags: c.tags.map((t) => tagChip(lang, t)),
    onOpen: () => { setState({ co: i, screen: 'vendor' }); scrollTop() },
  })
  const scrollTop = () => {
    const el = document.querySelector('.ph .scroll') as HTMLElement | null
    if (el) el.scrollTop = 0
  }
  const companies = comps.map(mkCompany)
  const companiesTop = [comps[3], comps[0]].map((c) => mkCompany(c, comps.indexOf(c)))

  const filterLabels = ar ? ['الأقرب', 'الأرخص', 'الأعلى تقييماً', 'متاح اليوم', 'الأدوات', 'فوري'] : ['Nearest', 'Lowest price', 'Top rated', 'Available', 'Tools', 'Instant']
  const filters = filterLabels.map((f, i) => ({
    label: f, onSelect: () => set('activeFilter', i),
    style: i === s.activeFilter ? 'background:#1E63FF;color:#fff;padding:8px 13px;font-size:12px;font-weight:600;border-radius:30px;white-space:nowrap' : 'background:var(--card);color:var(--soft);padding:8px 13px;font-size:12px;font-weight:600;border-radius:30px;border:1px solid var(--line);white-space:nowrap',
  }))

  const coView = {
    mono: co.mono, grad: co.grad, name: co.name[lang], tag: co.tag[lang], rating: co.rating, reviews: co.reviews, dist: co.dist, hero: co.hero, priceLabel: fmt(lang, co.base), coverage: co.coverage[lang],
    services: ar ? ['تنظيف عميق', 'مطابخ', 'حمامات', 'نوافذ', 'كنب', 'سجاد'] : ['Deep clean', 'Kitchens', 'Bathrooms', 'Windows', 'Sofas', 'Carpets'],
    gallery: [
      { emoji: '🛋️', bg: 'linear-gradient(135deg,#EAF0FF,#dbe6ff)' }, { emoji: '🍽️', bg: 'linear-gradient(135deg,#E7F8EF,#d3f2e0)' },
      { emoji: '🚿', bg: 'linear-gradient(135deg,#FFF4E0,#ffe9c4)' }, { emoji: '🪟', bg: 'linear-gradient(135deg,#F0E9FF,#e4d8ff)' },
    ],
  }

  const cleaningTypes = L.ct.map((label, i) => ({
    label, emoji: ['🧹', '🫧', '📦', '🛋️', '🏗️'][i], priceLabel: fmt(lang, RATES[i]), onSelect: () => set('ctIdx', i),
    chipStyle: chipSel(i === s.ctIdx), titleColor: i === s.ctIdx ? '#1E63FF' : 'var(--ink)',
  }))
  const propertyTypes = L.pt.map((label, i) => ({
    label, emoji: ['🏠', '🛏️', '🛏️', '🛌', '🏘️', '🏡'][i], mult: L.pm[i], onSelect: () => setState({ ptIdx: i, propOpen: false }),
    chipStyle: chipSel(i === s.ptIdx), titleColor: i === s.ptIdx ? '#1E63FF' : 'var(--ink)',
    multStyle: (i < 2) ? 'background:var(--field);color:var(--muted);padding:3px 8px;font-size:10.5px;font-weight:700;border-radius:30px' : 'background:rgba(245,166,35,.15);color:#B9770E;padding:3px 8px;font-size:10.5px;font-weight:700;border-radius:30px',
  }))
  const datesV = dates.map((d, i) => ({
    dow: d.dow, day: d.day, mon: d.mon, onSelect: () => set('dateIdx', i),
    cardStyle: i === s.dateIdx ? 'background:#1E63FF;border:1.5px solid #1E63FF' : 'background:var(--card);border:1.5px solid var(--line)',
    numColor: i === s.dateIdx ? '#fff' : 'var(--ink)', subColor: i === s.dateIdx ? 'rgba(255,255,255,.85)' : 'var(--muted)',
  }))
  const timesV = times.map((t, i) => ({
    label: t, onSelect: () => set('timeIdx', i),
    cardStyle: i === s.timeIdx ? 'background:rgba(30,99,255,.1);border:1.5px solid #1E63FF' : 'background:var(--card);border:1.5px solid var(--line)',
    color: i === s.timeIdx ? '#1E63FF' : 'var(--ink)',
  }))
  const instrChips = L.instr.map((label, i) => {
    const on = s.instr.includes(i)
    return {
      label: (on ? '✓ ' : '') + label,
      onToggle: () => { const a = s.instr.includes(i) ? s.instr.filter((x) => x !== i) : [...s.instr, i]; set('instr', a) },
      style: on ? 'background:rgba(30,99,255,.1);border:1.5px solid #1E63FF;color:#1E63FF;padding:8px 13px;font-size:12px;font-weight:700;border-radius:30px' : 'background:var(--field);border:1.5px solid var(--line);color:var(--soft);padding:8px 13px;font-size:12px;font-weight:600;border-radius:30px',
    }
  })

  const payData: [string, string, string, string][] = [
    ['pay0', '💳', 'rgba(30,99,255,.1)', '#1E63FF'], ['pay1', '', '#0E1726', '#fff'], ['pay2', 'G', '#fff', '#4285F4'],
    ['pay3', 'M', 'rgba(124,58,237,.12)', '#7C3AED'], ['pay4', 'V', 'rgba(230,0,0,.1)', '#E60000'], ['pay5', '⚡', 'rgba(22,179,100,.12)', '#0F8B4C'], ['pay6', '💵', 'rgba(245,166,35,.15)', '#B9770E'],
  ]
  const payMethods = payData.map((m, i) => {
    const pair = (L as any)[m[0]] as [string, string]
    return {
      label: pair[0], sub: pair[1], icon: m[1], iconBg: m[2], iconColor: m[3], onSelect: () => set('payIdx', i),
      cardStyle: i === s.payIdx ? 'background:rgba(30,99,255,.07);border:1.5px solid #1E63FF' : 'background:var(--card);border:1.5px solid var(--line)',
      radioBorder: i === s.payIdx ? '#1E63FF' : 'var(--line)',
      radioDot: i === s.payIdx ? <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#1E63FF' }} /> : '',
    }
  })

  const dsel = dates[s.dateIdx]
  const summaryRows = [
    { k: L.service, v: L.ct[s.ctIdx] }, { k: L.property, v: L.pt[s.ptIdx] }, { k: L.hours, v: s.hours + '' }, { k: L.cleanersK, v: s.cleaners + '' },
    { k: L.dateTime, v: dsel.full + ' · ' + times[s.timeIdx] }, { k: (ar ? 'العنوان' : 'Address'), v: (s.address || L.none) },
  ]
  const isCash = s.payIdx === 6
  const successRows = [
    { k: ar ? 'رقم الحجز' : 'Booking ID', v: s.lastId || '—' }, { k: L.service, v: co.name[lang] + ' · ' + L.ct[s.ctIdx] },
    { k: L.dateTime, v: dsel.full + ' · ' + times[s.timeIdx] }, { k: L.addr, v: (s.address || L.none) },
  ]

  const badgeFor = (status: string) => status === 'upcoming'
    ? { badge: '● ' + L.confirmed, badgeStyle: 'background:rgba(22,179,100,.13);color:#0F8B4C;padding:5px 10px;border-radius:30px;font-size:10.5px;font-weight:800' }
    : { badge: L.completed, badgeStyle: 'background:var(--field);color:var(--soft);padding:5px 10px;border-radius:30px;font-size:10.5px;font-weight:800' }
  const filteredBk = s.bookings.filter((b) => b.status === s.histTab)
  const historyList = filteredBk.map((b) => { const pp = payPill(lang, b.paid, b.paid ? b.method : 'cash'); return { ...b, ...badgeFor(b.status), payLabel: pp.label, payStyle: pp.style } })
  const upcomingBks = s.bookings.filter((b) => b.status === 'upcoming')
  const up = (upcomingBks[0] || {}) as Partial<AppState['bookings'][number]>

  const passFilter = (j: AppState['cIncoming'][number]) => {
    const dOk = s.dashDate === 'today' ? j.bucket === 'today' : true
    const sOk = s.dashSvc === 'all' || String(j.svcIdx) === s.dashSvc
    const stOk = s.dashStaff === 'all' || j.staff === s.dashStaff
    return dOk && sOk && stOk
  }
  const incomingList = s.cIncoming.map((j, i) => ({ j, i })).filter((x) => passFilter(x.j)).map(({ j, i }) => {
    const pp = payPill(lang, j.paid, j.paid ? (j.payMethod || 'card') : 'cash')
    let action: React.ReactNode
    if (j.state === 'pending') action = (
      <div style={{ display: 'flex', gap: '8px' }}>
        {btn(L.decline, 'var(--field)', 'var(--soft)', () => updIncoming(i, 'declined'))}
        {btn(L.approve, '#16B364', '#fff', () => updIncoming(i, 'approved'))}
      </div>
    )
    else if (j.state === 'new') action = btn(L.acknowledge, '#1E63FF', '#fff', () => updIncoming(i, 'ack'))
    else if (j.state === 'approved') action = <span style={{ color: '#0F8B4C', fontWeight: 800, fontSize: '12px' }}>{'✓ ' + L.approve}</span>
    else if (j.state === 'declined') action = <span style={{ color: '#E5484D', fontWeight: 800, fontSize: '12px' }}>{'✕ ' + L.decline}</span>
    else action = <span style={{ color: '#1E63FF', fontWeight: 800, fontSize: '12px' }}>{'✓ ' + L.inProcess}</span>
    return { customer: j.customer, service: j.service, datetime: j.datetime, total: j.total, methodLabel: pp.label, methodStyle: pp.style, action }
  })
  const pendingCount = s.cIncoming.filter((j) => j.state === 'pending' || j.state === 'new').length

  const chartData = [40, 62, 35, 80, 55, 100, 48]
  const cmax = Math.max(...chartData)
  const chartDows = ar ? ['سبت', 'أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع'] : ['Sa', 'Su', 'Mo', 'Tu', 'We', 'Th', 'Fr']
  const chartBars = chartData.map((v, i) => ({ h: (v / cmax * 100) + '%', d: chartDows[i], fill: v === cmax ? '#1E63FF' : 'rgba(30,99,255,.28)' }))
  const fchip = (on: boolean) => on ? 'background:#1E63FF;color:#fff;padding:7px 13px;border-radius:30px;font-size:11.5px;font-weight:700;white-space:nowrap;cursor:pointer' : 'background:var(--card);color:var(--soft);border:1px solid var(--line);padding:7px 13px;border-radius:30px;font-size:11.5px;font-weight:700;white-space:nowrap;cursor:pointer'
  const dateOpts = ([['today', ar ? 'اليوم' : 'Today'], ['week', ar ? 'هذا الأسبوع' : 'This week'], ['month', ar ? 'هذا الشهر' : 'This month']] as [AppState['dashDate'], string][]).map((o) => ({ label: o[1], onSel: () => set('dashDate', o[0]), style: fchip(s.dashDate === o[0]) }))
  const svcOpts = ([{ k: 'all', label: ar ? 'كل الخدمات' : 'All services' }] as { k: string; label: string }[]).concat(s.cServices.map((sv) => ({ k: String(sv.typeIdx), label: L.ct[sv.typeIdx] }))).map((o) => ({ label: o.label, onSel: () => set('dashSvc', o.k), style: fchip(s.dashSvc === o.k) }))
  const staffOpts = ([{ k: 'all', label: ar ? 'كل الطاقم' : 'All staff' }] as { k: string; label: string }[]).concat(s.staff.map((st) => ({ k: st.name, label: st.name.split(' ')[0] }))).map((o) => ({ label: o.label, onSel: () => set('dashStaff', o.k), style: fchip(s.dashStaff === o.k) }))
  const canSaveStaff = s.staffForm.name.trim().length > 0

  const cServices = s.cServices.map((sv) => ({
    emoji: svcEmoji(sv.typeIdx), iconBg: svcBg(sv.typeIdx), name: L.ct[sv.typeIdx], desc: L.cts[sv.typeIdx],
    rate: fmt(lang, sv.rate), cleaners: sv.cleaners + ' ' + L.cleanersAvail, capacity: L.capacity + ' ' + sv.capacity,
    onEdit: () => setState({ svcForm: { editId: sv.id, typeIdx: sv.typeIdx, rate: sv.rate, cleaners: sv.cleaners, capacity: sv.capacity }, screen: 'cServiceForm' }),
  }))
  const coverageAreas = co.coverage[lang].split(/[,،]/).map((x) => x.trim())

  const filteredCH = s.cHistory.filter((b) => b.status === s.histTab)
  const cHistoryList = filteredCH.map((b) => { const pp = payPill(lang, b.paid, b.paid ? b.method : 'cash'); return { ...b, ...badgeFor(b.status), payLabel: pp.label, payStyle: pp.style } })

  const notifList = [
    { icon: '💵', iconBg: 'rgba(245,166,35,.15)', title: L.newBookingCash, body: (ar ? 'أحمد يوسف · تنظيف عميق ٣ ساعات — ' : 'Ahmed Youssef · Deep clean 3h — ') + L.needsApproval, time: ar ? 'منذ ٥ دقائق' : '5 min ago', action: <div style={{ display: 'flex', gap: '8px' }}>{btn(L.decline, 'var(--field)', 'var(--soft)', () => {})}{btn(L.approve, '#16B364', '#fff', () => {})}</div> },
    { icon: '✓', iconBg: 'rgba(22,179,100,.12)', title: L.newBookingPaid, body: (ar ? 'منى صالح · عادي ٢ ساعة · مدفوع بالكامل' : 'Mona Saleh · Standard 2h · paid in full'), time: ar ? 'منذ ٢٠ دقيقة' : '20 min ago', action: btn(L.acknowledge + ' · ' + L.inProcess, '#1E63FF', '#fff', () => {}) },
    { icon: '⭐', iconBg: 'rgba(245,166,35,.15)', title: ar ? 'تقييم جديد' : 'New review', body: ar ? 'حصلت على ٥ نجوم من يوسف علي' : 'You received a 5-star rating from Youssef Ali', time: ar ? 'منذ ساعة' : '1h ago', action: <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: 600 }}>⭐⭐⭐⭐⭐</span> },
  ]

  const lockedDocs = [
    { icon: '📄', label: L.tradeLicence, value: 'TL-2019-88421', expiry: '12 / 2026', expSoon: false },
    { icon: '🪪', label: L.ownerId, value: ar ? 'أحمد سباركل' : 'Ahmed Sparkle', expiry: '09 / 2026', expSoon: true },
    { icon: '🏢', label: L.companyName, value: co.name[lang], expiry: null as string | null, expSoon: false },
  ].map((d) => ({
    ...d,
    expLabel: d.expiry ? ((d.expSoon ? (ar ? '⚠ تنتهي قريباً ' : '⚠ Expiring soon ') : (ar ? 'تنتهي ' : 'Valid till ')) + d.expiry) : '',
    expStyle: d.expSoon ? 'color:#B9770E;font-weight:800' : 'color:#0F8B4C;font-weight:700',
    expBg: d.expSoon ? 'background:rgba(245,166,35,.08)' : '',
  }))

  const uploads = ([{ key: 'lic', icon: '📄', label: L.tradeLicence }, { key: 'id', icon: '🪪', label: L.ownerId }] as const).map((u) => {
    const field = ('up_' + u.key) as 'up_lic' | 'up_id'
    const done = s[field]
    return {
      label: u.label, icon: u.icon, onUpload: () => set(field, true),
      style: done ? 'background:rgba(22,179,100,.08);border:1.5px solid rgba(22,179,100,.4)' : 'background:var(--field);border:1.5px dashed var(--line)',
      iconBg: done ? 'rgba(22,179,100,.15)' : 'rgba(30,99,255,.1)',
      sub: done ? L.uploaded : L.tapUpload, subColor: done ? '#0F8B4C' : 'var(--muted)',
      check: done
        ? <svg width={20} height={20} viewBox="0 0 24 24" fill="none"><circle cx={12} cy={12} r={10} fill="#16B364" /><path d="M7 12l3 3 7-7" stroke="#fff" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" /></svg>
        : <span style={{ color: '#1E63FF', fontSize: '20px', fontWeight: 800 }}>＋</span>,
    }
  })

  const app = s.app
  const custScreens: Screen[] = ['home', 'search', 'bookings', 'account']
  const compScreens: Screen[] = ['cHome', 'cServices', 'cHistory', 'cNotifs', 'cProfile']

  return {
    dir: (ar ? 'rtl' : 'ltr') as 'rtl' | 'ltr', backFlip: ar ? 'scaleX(-1)' : 'none',
    L, langLabel: ar ? 'EN' : 'عربي', langFull: ar ? 'العربية' : 'English', themeIcon: s.theme === 'dark' ? '☀️' : '🌙', themeLabel: s.theme === 'dark' ? (ar ? 'داكن' : 'Dark') : (ar ? 'فاتح' : 'Light'),
    chevron: ar ? '‹' : '›', greeting: L.greeting,
    toggleLang: () => set('lang', ar ? 'en' : 'ar'), toggleTheme: () => set('theme', s.theme === 'dark' ? 'light' : 'dark'),

    isSplash: screen === 'splash', isLogin: screen === 'login', isSignup: screen === 'signup', isCorpReg: screen === 'corpReg', isReview: screen === 'review',
    isHome: screen === 'home', isSearch: screen === 'search', isVendor: screen === 'vendor', isConfig: screen === 'config', isSchedule: screen === 'schedule',
    isSummary: screen === 'summary', isPayment: screen === 'payment', isSuccess: screen === 'success', isBookings: screen === 'bookings', isAccount: screen === 'account',
    isCHome: screen === 'cHome', isCServices: screen === 'cServices', isCHistory: screen === 'cHistory', isCNotifs: screen === 'cNotifs', isCProfile: screen === 'cProfile',

    sbBg: (screen === 'home' || screen === 'vendor' || screen === 'cHome' || screen === 'cProfile' || screen === 'splash') ? (screen === 'cHome' ? '#0E1726' : (screen === 'cProfile' ? '#7C3AED' : '#1E63FF')) : 'var(--card)',
    sbInk: (screen === 'home' || screen === 'vendor' || screen === 'cHome' || screen === 'cProfile' || screen === 'splash') ? '#fff' : 'var(--ink)',

    showCustNav: app === 'customer' && custScreens.includes(screen),
    showCompNav: app === 'company' && compScreens.includes(screen),
    navHome: screen === 'home' ? '#1E63FF' : 'var(--navicon)', navSearch: screen === 'search' ? '#1E63FF' : 'var(--navicon)', navBookings: screen === 'bookings' ? '#1E63FF' : 'var(--navicon)', navAccount: screen === 'account' ? '#1E63FF' : 'var(--navicon)',
    navCHome: screen === 'cHome' ? '#1E63FF' : 'var(--navicon)', navCServices: screen === 'cServices' ? '#1E63FF' : 'var(--navicon)', navCHistory: screen === 'cHistory' ? '#1E63FF' : 'var(--navicon)', navCNotifs: screen === 'cNotifs' ? '#1E63FF' : 'var(--navicon)', navCProfile: screen === 'cProfile' ? '#1E63FF' : 'var(--navicon)',
    goHome: () => go('home'), goSearch: () => go('search'), goBookings: () => go('bookings'), goAccount: () => go('account'),
    goCHome: () => go('cHome'), goCServices: () => go('cServices'), goCHistory: () => go('cHistory'), goCProfile: () => go('cProfile'),
    isCustNotifs: screen === 'custNotifs', goCustNotifs: () => go('custNotifs'),
    custNotifList: [
      { icon: '✅', iconBg: 'rgba(22,179,100,.12)', title: ar ? 'تم تأكيد الحجز' : 'Booking confirmed', body: ar ? 'Sparkle Masr · تنظيف عميق يوم الخميس ١٠:٠٠' : 'Sparkle Masr · Deep clean on Thu 10:00', time: ar ? 'منذ ٥ دقائق' : '5 min ago', unread: true },
      { icon: '⏰', iconBg: 'rgba(30,99,255,.1)', title: ar ? 'تذكير بالموعد' : 'Upcoming reminder', body: ar ? 'فريقك يصل غداً الساعة ١٠ صباحاً' : 'Your team arrives tomorrow at 10:00', time: ar ? 'منذ ساعة' : '1h ago', unread: true },
      { icon: '⭐', iconBg: 'rgba(245,166,35,.15)', title: ar ? 'قيّم خدمتك' : 'Rate your service', body: ar ? 'كيف كانت تجربتك مع Lamsa Home؟' : 'How was your clean with Lamsa Home?', time: ar ? 'أمس' : 'Yesterday', unread: false },
      { icon: '🎁', iconBg: 'rgba(124,58,237,.12)', title: ar ? 'خصم ٥٠٪' : '50% off your next clean', body: ar ? 'استخدم كود CLEAN50 قبل نهاية الأسبوع' : 'Use code CLEAN50 before the weekend', time: ar ? 'منذ يومين' : '2 days ago', unread: false },
    ],

    segIndividual: (s.acct === 'individual') ? 'flex:1;text-align:center;padding:11px;border-radius:11px;background:#1E63FF;color:#fff;font-weight:800;font-size:13px;cursor:pointer' : 'flex:1;text-align:center;padding:11px;border-radius:11px;color:var(--soft);font-weight:700;font-size:13px;cursor:pointer',
    segCorporate: (s.acct === 'corporate') ? 'flex:1;text-align:center;padding:11px;border-radius:11px;background:#1E63FF;color:#fff;font-weight:800;font-size:13px;cursor:pointer' : 'flex:1;text-align:center;padding:11px;border-radius:11px;color:var(--soft);font-weight:700;font-size:13px;cursor:pointer',
    pickIndividual: () => set('acct', 'individual'), pickCorporate: () => set('acct', 'corporate'),
    loginBtnLabel: s.acct === 'corporate' ? (ar ? 'دخول كشركة' : 'Log in as company') : (ar ? 'دخول' : 'Log in'),
    doLogin: () => { if (s.acct === 'corporate') setState({ app: 'company', corpApproved: true, screen: 'cHome' }); else setState({ app: 'customer', screen: 'home' }) },
    goSignup: () => go('signup'), goLogin: () => go('login'),
    signupNameLabel: s.acct === 'corporate' ? L.companyName : (ar ? 'الاسم الكامل' : 'Full name'), signupNamePh: s.acct === 'corporate' ? L.companyNamePh : (ar ? 'رنا مصطفى' : 'Rana Mostafa'),
    signupBtnLabel: s.acct === 'corporate' ? (ar ? 'متابعة' : 'Continue') : L.createAccount,
    doSignup: () => { if (s.acct === 'corporate') go('corpReg'); else setState({ app: 'customer', screen: 'home' }) },
    uploads, submitReview: () => setState({ corpApproved: false, screen: 'review' }),
    simulateApprove: () => setState({ app: 'company', corpApproved: true, screen: 'cHome' }),
    enterLimited: () => setState({ app: 'company', corpApproved: false, screen: 'cHome' }),

    userName: L.userName, companiesTop,
    hasUpcoming: upcomingBks.length > 0, up: { mono: up.mono, grad: up.grad, name: up.name, service: up.service, datetime: up.datetime },
    serviceTiles: [{ emoji: '🧹', label: L.ct[0] }, { emoji: '🫧', label: L.ct[1] }, { emoji: '🛋️', label: L.ct[3] }, { emoji: '🪟', label: ar ? 'نوافذ' : 'Windows' }],

    searchQuery: s.searchQuery, onSearch: (e: React.ChangeEvent<HTMLInputElement>) => set('searchQuery', e.target.value), companies, filters,
    resultsLabel: comps.length + ' ' + L.results,

    co: coView, startBooking: () => setState({ screen: 'config' }), goVendor: () => go('vendor'),

    booking: { hours: s.hours, cleaners: s.cleaners, address: s.address, notes: s.notes },
    cleaningTypes, propertyTypes, dates: datesV, times: timesV, instrChips,
    propOpen: s.propOpen, openProp: () => set('propOpen', true), closeProp: () => set('propOpen', false),
    propLabel: L.pt[s.ptIdx], propMultLabel: L.pm[s.ptIdx], propEmoji: ['🏠', '🛏️', '🛏️', '🛌', '🏘️', '🏡'][s.ptIdx],
    propMultStyle: (s.ptIdx < 2) ? 'background:var(--field);color:var(--muted);padding:4px 9px;font-size:11px;font-weight:700;border-radius:30px' : 'background:rgba(245,166,35,.15);color:#B9770E;padding:4px 9px;font-size:11px;font-weight:700;border-radius:30px',
    chooseWord: ar ? 'اختر نوع العقار' : 'Select property type',
    hoursInc: () => set('hours', Math.min(12, s.hours + 1)), hoursDec: () => set('hours', Math.max(1, s.hours - 1)),
    cleanersInc: () => set('cleaners', Math.min(4, s.cleaners + 1)), cleanersDec: () => set('cleaners', Math.max(1, s.cleaners - 1)),
    toggleSupplies: () => set('supplies', !s.supplies), suppliesPrice: fmt(lang, 100),
    suppliesBorder: s.supplies ? '#1E63FF' : 'var(--line)', suppliesTrack: s.supplies ? '#1E63FF' : 'var(--line)', suppliesKnob: ar ? (s.supplies ? 'right' : 'left') : (s.supplies ? 'left' : 'right'),
    onAddress: (e: React.ChangeEvent<HTMLInputElement>) => set('address', e.target.value), onNotes: (e: React.ChangeEvent<HTMLTextAreaElement>) => set('notes', e.target.value),
    useLocation: () => set('address', ar ? '٩ شارع التسعين، التجمع الخامس، القاهرة' : '9 Ninety St, New Cairo, Cairo'),
    goConfig: () => go('config'), goSchedule: () => go('schedule'), goSummary: () => go('summary'),
    estTotal: fmt(lang, p.total),

    summaryRows, priceLabour: fmt(lang, p.labour), priceSupplies: fmt(lang, p.supplies), priceSubtotal: fmt(lang, p.subtotal), priceFee: fmt(lang, p.fee), priceVat: fmt(lang, p.vat), priceTotal: fmt(lang, p.total),
    agree: s.agree, toggleAgree: () => set('agree', !s.agree),
    agreeBg: s.agree ? 'rgba(22,179,100,.08)' : 'var(--card)', agreeBorder: s.agree ? 'rgba(22,179,100,.4)' : 'var(--line)', checkBg: s.agree ? '#16B364' : 'transparent', checkBorder: s.agree ? '#16B364' : 'var(--muted)',
    checkMark: s.agree ? <svg width={12} height={12} viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#fff" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" /></svg> : '',
    continueToPayment: () => { if (s.agree) go('payment') },
    payBtnBg: (screen === 'payment' ? (s.payIdx != null) : s.agree) ? '#1E63FF' : 'var(--line)', payBtnColor: (screen === 'payment' ? (s.payIdx != null) : s.agree) ? '#fff' : 'var(--muted)',
    payBtnLabel: (isCash ? (ar ? 'تأكيد الطلب' : 'Confirm request') : L.pay + ' ' + fmt(lang, p.total)),

    payMethods,
    pay: () => {
      if (s.payIdx == null) return
      const mkey = payIdxKey(s.payIdx); const isCashSel = mkey === 'cash'
      const id = 'EGY-' + Math.floor(100000 + Math.random() * 900000)
      const entry = { mono: co.mono, grad: co.grad, name: co.name[lang], service: L.ct[s.ctIdx], datetime: dsel.full + ' · ' + times[s.timeIdx], id, total: fmt(lang, p.total), status: 'upcoming' as const, paid: !isCashSel, method: mkey }
      setState({ lastId: id, lastMethod: isCashSel ? 'cash' : mkey, bookings: [entry, ...s.bookings], screen: 'success' })
    },
    goPayment: () => go('payment'),
    successHeadline: s.lastMethod === 'cash' ? L.bookingRequested : L.paySuccess, successRows, viewBookings: () => go('bookings'),

    histTab: s.histTab, tabUpcoming: () => set('histTab', 'upcoming'), tabPast: () => set('histTab', 'past'),
    tabUpStyle: s.histTab === 'upcoming' ? 'font-weight:800;font-size:14px;color:#1E63FF;padding-bottom:10px;border-bottom:2.5px solid #1E63FF;cursor:pointer' : 'font-weight:700;font-size:14px;color:var(--muted);padding-bottom:10px;cursor:pointer',
    tabPastStyle: s.histTab === 'past' ? 'font-weight:800;font-size:14px;color:#1E63FF;padding-bottom:10px;border-bottom:2.5px solid #1E63FF;cursor:pointer' : 'font-weight:700;font-size:14px;color:var(--muted);padding-bottom:10px;cursor:pointer',
    historyList, hasListItems: historyList.length > 0, emptyList: historyList.length === 0, emptyTitle: s.histTab === 'upcoming' ? L.emptyUpTitle : L.emptyPastTitle,

    photoBg: s.photo ? 'linear-gradient(135deg,#1E63FF,#1546C0)' : 'var(--field)', photoContent: s.photo ? 'RM' : '👤', photoBtnSide: ar ? 'left' : 'right',
    photoBg2: s.photo ? '#fff' : 'rgba(255,255,255,.28)', photoContent2: s.photo ? (ar ? 'ر' : 'R') : '👤',
    isCustProfile: screen === 'custProfile', openCustProfile: () => go('custProfile'), backToAccount: () => go('account'),
    pName: s.pName || (ar ? 'رنا مصطفى' : 'Rana Mostafa'), pEmail: s.pEmail || 'rana@email.com', pPhone: s.pPhone || '+20 100 123 4567', pCity: s.pCity || (ar ? 'القاهرة الجديدة' : 'New Cairo'),
    onPName: (e: React.ChangeEvent<HTMLInputElement>) => set('pName', e.target.value), onPEmail: (e: React.ChangeEvent<HTMLInputElement>) => set('pEmail', e.target.value), onPPhone: (e: React.ChangeEvent<HTMLInputElement>) => set('pPhone', e.target.value), onPCity: (e: React.ChangeEvent<HTMLInputElement>) => set('pCity', e.target.value),
    editingProfile: s.editingProfile, notEditingProfile: !s.editingProfile, startEditProfile: () => set('editingProfile', true), saveProfile: () => set('editingProfile', false),
    profileTitle: ar ? 'الملف الشخصي' : 'Personal details', memberSince: ar ? 'عضو منذ ٢٠٢٤' : 'Member since 2024',
    fullNameW: ar ? 'الاسم الكامل' : 'Full name', emailW: ar ? 'البريد الإلكتروني' : 'Email', mobileW: ar ? 'رقم الموبايل' : 'Mobile number', cityW: ar ? 'المدينة / المنطقة' : 'City / Area', saveProfileW: ar ? 'حفظ البيانات' : 'Save details',
    photoHint: s.photo ? (ar ? 'اضغط لتغيير الصورة' : 'Tap to change photo') : (ar ? 'اضغط لإضافة صورة' : 'Tap to add photo'),
    addPhoto: () => set('photo', !s.photo), walletBal: fmt(lang, 450), addCard: () => {}, logout: () => setState({ app: 'auth', screen: 'login', acct: 'individual' }),

    notApproved: !s.corpApproved, statToday: '4', statEarnings: fmt(lang, 18400),
    incomingList, hasPending: pendingCount > 0, pendingCount,
    goCNotifs: () => go('cNotifs'),

    cServices, coverageAreas,
    addService: () => setState({ svcForm: { editId: null, typeIdx: 0, rate: 100, cleaners: 1, capacity: '' }, screen: 'cServiceForm' }),
    isCServiceForm: screen === 'cServiceForm', isCStaffForm: screen === 'cStaffForm',
    backToServices: () => go('cServices'), backToProfile: () => go('cProfile'),
    editWord: ar ? 'تعديل ✎' : 'Edit ✎',
    svcFormTitle: (s.svcForm && s.svcForm.editId) ? (ar ? 'تعديل الخدمة' : 'Edit service') : (ar ? 'إضافة خدمة' : 'Add service'),
    svcTypeOpts: L.ct.map((label, i) => ({ label, emoji: svcEmoji(i), onSel: () => setSvc('typeIdx', i), style: (s.svcForm && s.svcForm.typeIdx === i) ? 'background:rgba(30,99,255,.08);border:1.5px solid #1E63FF' : 'background:var(--card);border:1.5px solid var(--line)', color: (s.svcForm && s.svcForm.typeIdx === i) ? '#1E63FF' : 'var(--ink)' })),
    svcRateLabel: fmt(lang, s.svcForm ? s.svcForm.rate : 0), svcCleaners: s.svcForm ? s.svcForm.cleaners : 1, svcCapacity: s.svcForm ? s.svcForm.capacity : '',
    onSvcCapacity: (e: React.ChangeEvent<HTMLInputElement>) => setSvc('capacity', e.target.value),
    svcCleanersInc: () => setSvc('cleaners', Math.min(8, (s.svcForm ? s.svcForm.cleaners : 1) + 1)), svcCleanersDec: () => setSvc('cleaners', Math.max(1, (s.svcForm ? s.svcForm.cleaners : 1) - 1)),
    svcRateInc: () => setSvc('rate', (s.svcForm ? s.svcForm.rate : 0) + 10), svcRateDec: () => setSvc('rate', Math.max(0, (s.svcForm ? s.svcForm.rate : 0) - 10)),
    saveService, deleteService, canDeleteSvc: !!(s.svcForm && s.svcForm.editId),
    rateWord: ar ? 'السعر بالساعة' : 'Rate per hour', cleanersWord: ar ? 'عدد العمال' : 'Cleaners', capacityWord: ar ? 'السعة' : 'Capacity', capacityPh: ar ? 'مثال: ١٢٠م² أو ٦ قطع' : 'e.g. 120m² or 6 pcs',
    saveServiceWord: ar ? 'حفظ الخدمة' : 'Save service', deleteWord: ar ? 'حذف الخدمة' : 'Delete service',

    staffTitle: ar ? 'الطاقم' : 'Staff', addStaffWord: ar ? 'إضافة' : 'Add staff', jobsWord: ar ? 'مهمة' : 'jobs',
    staffList: s.staff.map((st, i) => ({ name: st.name, mono: st.mono || ((st.name.trim()[0] || '?').toUpperCase()), color: st.color, role: st.role, jobs: st.jobs || 0, ratingLabel: (st.rating || 5).toFixed(1), stars: stars(st.rating || 5), onRemove: () => removeStaff(i) })),
    addStaff: () => setState({ staffForm: { name: '', role: '', color: '#1E63FF' }, screen: 'cStaffForm' }),
    staffFormName: s.staffForm.name, staffFormRole: s.staffForm.role,
    onStaffName: (e: React.ChangeEvent<HTMLInputElement>) => setStaff('name', e.target.value), onStaffRole: (e: React.ChangeEvent<HTMLInputElement>) => setStaff('role', e.target.value),
    staffColorOpts: ['#1E63FF', '#16B364', '#F5A623', '#7C3AED', '#E5484D'].map((c) => ({ c, onSel: () => setStaff('color', c), ring: s.staffForm.color === c ? '0 0 0 3px var(--card),0 0 0 5px ' + c : 'none' })),
    staffMonoPreview: (s.staffForm.name.trim()[0] || '+').toUpperCase(), staffColor: s.staffForm.color,
    saveStaff, saveStaffBg: canSaveStaff ? '#1E63FF' : 'var(--line)', saveStaffColor: canSaveStaff ? '#fff' : 'var(--muted)',
    photoAutoNote: ar ? 'تُنشأ الأيقونة تلقائياً' : 'Monogram auto-generated', staffNameWord: ar ? 'الاسم' : 'Name', staffNamePh: ar ? 'مثال: خالد إبراهيم' : 'e.g. Khaled Ibrahim', staffRoleWord: ar ? 'الدور' : 'Role', staffRolePh: ar ? 'مثال: أخصائي تنظيف عميق' : 'e.g. Deep-clean specialist', saveStaffWord: ar ? 'إضافة للطاقم' : 'Add to staff',

    analyticsTitle: ar ? 'نظرة عامة' : 'Overview', statMonthJobs: '42', statJobsLabel: ar ? 'حجوزات الشهر' : 'Jobs (mo)', statPaidPct: '88%', statPaidLabel: ar ? 'مدفوعة' : 'Paid', statRating: '4.9', statRatingLabel: ar ? 'التقييم' : 'Rating',
    chartTitle: ar ? 'أرباح الأسبوع' : 'This week', chartMaxLabel: fmt(lang, 2400), chartBars,
    filterWord: ar ? 'تصفية النتائج' : 'Filter results', dateOpts, svcOpts, staffOpts,

    cHistoryList,
    notifList,

    approvalBadge: s.corpApproved ? ('✓ ' + L.approved) : ('⏳ ' + L.pendingReview),
    mgrContact: s.mgr || '+20 100 555 1234', supContact: s.sup || '+20 109 888 7766',
    onMgr: (e: React.ChangeEvent<HTMLInputElement>) => set('mgr', e.target.value), onSup: (e: React.ChangeEvent<HTMLInputElement>) => set('sup', e.target.value),
    saveContacts: () => setState({ savedContacts: true, editingContacts: false }), saveLabel: L.save,
    editingContacts: s.editingContacts, notEditingContacts: !s.editingContacts,
    startEditContacts: () => set('editingContacts', true), editWord2: ar ? 'تعديل' : 'Edit',

    filterOpen: s.filterOpen, openFilter: () => set('filterOpen', true), closeFilter: () => set('filterOpen', false), stop: (e: React.MouseEvent) => e.stopPropagation(),
    resetFilter: () => setState({ dashDate: 'week', dashSvc: 'all', dashStaff: 'all' }),
    filterActive: !(s.dashDate === 'week' && s.dashSvc === 'all' && s.dashStaff === 'all'),
    filterSummary: (() => { const n = (s.dashDate !== 'week' ? 1 : 0) + (s.dashSvc !== 'all' ? 1 : 0) + (s.dashStaff !== 'all' ? 1 : 0); return n === 0 ? (ar ? 'الكل' : 'All') : (n + ' ' + (ar ? 'مطبّق' : 'active')) })(),
    dateWord: ar ? 'التاريخ' : 'Date', resetWord: ar ? 'إعادة' : 'Reset', applyWord: ar ? 'تطبيق' : 'Apply results',
    lockedDocs,
  }
}

export type Vals = ReturnType<typeof buildVals>
