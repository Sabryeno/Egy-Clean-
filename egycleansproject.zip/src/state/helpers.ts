import type { Lang, Dict } from './i18n'
import type { AppState } from './types'
import { RATES, PROP_MULT } from './data'

export function fmt(lang: Lang, n: number): string {
  const cur = lang === 'ar' ? 'ج.م' : 'EGP'
  return cur + ' ' + Math.round(n).toLocaleString('en-US')
}

export function tagChip(lang: Lang, code: string): { label: string; style: string } {
  const ar = lang === 'ar'
  if (code === 'a') return { label: ar ? 'متاح اليوم' : 'Available today', style: 'background:rgba(22,179,100,.13);color:#0F8B4C;padding:3px 7px;font-size:10px;font-weight:700;border-radius:30px' }
  if (code === 't') return { label: ar ? 'الأدوات مشمولة' : 'Tools included', style: 'background:rgba(30,99,255,.1);color:#1546C0;padding:3px 7px;font-size:10px;font-weight:700;border-radius:30px' }
  return { label: ar ? 'حجز فوري' : 'Instant', style: 'background:rgba(245,166,35,.15);color:#B9770E;padding:3px 7px;font-size:10px;font-weight:700;border-radius:30px' }
}

export function methodMeta(lang: Lang, key: string): { l: string } {
  const ar = lang === 'ar'
  const m: Record<string, { l: string }> = {
    card: { l: ar ? 'بطاقة' : 'Card' }, applepay: { l: 'Apple Pay' }, gpay: { l: 'Google Pay' },
    meeza: { l: ar ? 'ميزة' : 'Meeza' }, vodafone: { l: ar ? 'فودافون كاش' : 'Vodafone Cash' },
    instapay: { l: 'InstaPay' }, cash: { l: ar ? 'كاش' : 'Cash' },
  }
  return m[key] || m.card
}

export function payIdxKey(i: number): string {
  return ['card', 'applepay', 'gpay', 'meeza', 'vodafone', 'instapay', 'cash'][i] || 'card'
}

export function payPill(lang: Lang, paid: boolean, key: string): { label: string; style: string } {
  const ar = lang === 'ar'
  const mm = methodMeta(lang, key)
  const base = 'padding:4px 9px;border-radius:30px;font-size:10px;font-weight:800;display:inline-block'
  if (paid) return { label: '✓ ' + (ar ? 'مدفوع' : 'Paid') + ' · ' + mm.l, style: 'background:rgba(22,179,100,.13);color:#0F8B4C;' + base }
  return { label: '● ' + (ar ? 'غير مدفوع' : 'Unpaid') + ' · ' + mm.l, style: 'background:rgba(245,166,35,.15);color:#B9770E;' + base }
}

export function svcEmoji(t: number): string {
  return ['🧹', '🫧', '📦', '🛋️', '🏗️'][t] || '🧹'
}

export function svcBg(t: number): string {
  return ['rgba(30,99,255,.1)', 'rgba(22,179,100,.12)', 'rgba(124,58,237,.12)', 'rgba(245,166,35,.15)', 'rgba(90,100,114,.12)'][t] || 'rgba(30,99,255,.1)'
}

export function stars(r: number): string {
  const full = Math.round(r)
  return '★★★★★'.slice(0, full) + '☆☆☆☆☆'.slice(0, 5 - full)
}

export interface PriceBreakdown {
  labour: number
  supplies: number
  subtotal: number
  fee: number
  vat: number
  total: number
}

export function price(s: AppState): PriceBreakdown {
  const rate = RATES[s.ctIdx], mult = PROP_MULT[s.ptIdx]
  const labour = rate * s.hours * s.cleaners * mult
  const supplies = s.supplies ? 100 : 0
  const subtotal = labour + supplies
  const fee = subtotal * 0.05
  const vat = subtotal * 0.14
  return { labour, supplies, subtotal, fee, vat, total: subtotal + fee + vat }
}

export interface DateItem { dow: string; day: number; mon: string; full: string }

export function dateList(L: Dict): DateItem[] {
  const out: DateItem[] = []
  const now = new Date('2026-07-13')
  for (let i = 0; i < 7; i++) {
    const d = new Date(now)
    d.setDate(now.getDate() + i)
    out.push({ dow: L.days[d.getDay()], day: d.getDate(), mon: L.months[d.getMonth()], full: L.days[d.getDay()] + ' ' + d.getDate() + ' ' + L.months[d.getMonth()] })
  }
  return out
}

export const chipSel = (a: boolean): string =>
  a ? 'background:rgba(30,99,255,.08);border:1.5px solid #1E63FF' : 'background:var(--card);border:1.5px solid var(--line)'
