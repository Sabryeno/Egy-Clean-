import type { AppState, CompanyDef } from './types'

export const COMPANIES: CompanyDef[] = [
  { mono: 'S', grad: 'linear-gradient(135deg,#1E63FF,#1546C0)', name: { en: 'Sparkle Masr', ar: 'سباركل مصر' }, tag: { en: 'Deep cleaning specialists · Nasr City', ar: 'متخصصو التنظيف العميق · مدينة نصر' }, rating: '4.9', reviews: 320, dist: '1.2', base: 90, tags: ['a', 't'], hero: '✨', coverage: { en: 'Nasr City, Heliopolis, Downtown', ar: 'مدينة نصر، مصر الجديدة، وسط البلد' } },
  { mono: 'N', grad: 'linear-gradient(135deg,#16B364,#0F8B4C)', name: { en: 'Nadafa Plus', ar: 'نضافة بلس' }, tag: { en: 'Home & office · Maadi', ar: 'منازل ومكاتب · المعادي' }, rating: '4.7', reviews: 210, dist: '2.6', base: 110, tags: ['i'], hero: '🧽', coverage: { en: 'Maadi, Zahraa, Katameya', ar: 'المعادي، الزهراء، القطامية' } },
  { mono: 'L', grad: 'linear-gradient(135deg,#F5A623,#E0850C)', name: { en: 'Lamsa Home', ar: 'لمسة' }, tag: { en: 'Move-in / move-out · Dokki', ar: 'انتقال السكن · الدقي' }, rating: '4.8', reviews: 180, dist: '3.4', base: 100, tags: ['t'], hero: '🏠', coverage: { en: 'Dokki, Mohandessin, Agouza', ar: 'الدقي، المهندسين، العجوزة' } },
  { mono: 'B', grad: 'linear-gradient(135deg,#7C3AED,#5B21B6)', name: { en: 'Bayti Clean', ar: 'بيتي كلين' }, tag: { en: 'Premium villa care · Zamalek', ar: 'عناية فاخرة بالفلل · الزمالك' }, rating: '4.9', reviews: 410, dist: '4.1', base: 140, tags: ['a', 't'], hero: '🌟', coverage: { en: 'Zamalek, Garden City, 6th October', ar: 'الزمالك، جاردن سيتي، السادس من أكتوبر' } },
]

export const RATES = [90, 130, 150, 110, 170]
export const PROP_MULT = [1, 1, 1.2, 1.4, 1.6, 1.8]
export const TIMES = ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00']

export function initialState(): AppState {
  return {
    screen: 'splash', app: 'auth', acct: 'individual', corpApproved: true, lang: 'en', theme: 'light',
    co: 0, activeFilter: 2, searchQuery: '',
    ctIdx: 0, ptIdx: 0, hours: 2, cleaners: 1, supplies: false, dateIdx: 1, timeIdx: 1, address: '', notes: '', instr: [], payIdx: null, agree: false,
    histTab: 'upcoming', photo: false, mgr: '', sup: '', savedContacts: true, editingContacts: false, filterOpen: false, propOpen: false,
    pName: '', pEmail: '', pPhone: '', pCity: '', editingProfile: false,
    lastId: '', lastMethod: 'card',
    cServices: [{ id: 1, typeIdx: 0, rate: 90, cleaners: 2, capacity: '120m²' }, { id: 2, typeIdx: 1, rate: 130, cleaners: 3, capacity: '200m²' }, { id: 3, typeIdx: 3, rate: 110, cleaners: 2, capacity: '6 pcs' }],
    staff: [
      { name: 'Ahmed Hassan', mono: 'A', color: '#1E63FF', rating: 4.9, jobs: 320, role: 'Lead cleaner' },
      { name: 'Mona Farid', mono: 'M', color: '#16B364', rating: 4.8, jobs: 210, role: 'Deep-clean specialist' },
      { name: 'Sara Nabil', mono: 'S', color: '#F5A623', rating: 4.7, jobs: 150, role: 'Upholstery care' },
    ],
    svcForm: null, staffForm: { name: '', role: '', color: '#1E63FF' },
    dashDate: 'week', dashSvc: 'all', dashStaff: 'all',
    bookings: [
      { mono: 'S', grad: 'linear-gradient(135deg,#1E63FF,#1546C0)', name: 'Sparkle Masr', service: 'Deep clean', datetime: 'Thu 16 Jul · 10:00', id: 'EGY-284417', total: 'EGP 618', status: 'upcoming', paid: true, method: 'card' },
      { mono: 'L', grad: 'linear-gradient(135deg,#F5A623,#E0850C)', name: 'Lamsa Home', service: 'Standard clean', datetime: 'Sun 5 Jul · 14:00', id: 'EGY-201355', total: 'EGP 297', status: 'past', paid: true, method: 'instapay' },
    ],
    cIncoming: [
      { customer: 'Omar Adel', service: 'Deep clean · 3h', datetime: 'Today 14:00', total: 'EGP 618', method: 'cash', state: 'pending', paid: false, staff: 'Ahmed Hassan', svcIdx: 1, bucket: 'today' },
      { customer: 'Mona Saleh', service: 'Standard · 2h', datetime: 'Today 17:00', total: 'EGP 297', method: 'paid', state: 'new', paid: true, payMethod: 'card', staff: 'Mona Farid', svcIdx: 0, bucket: 'today' },
      { customer: 'Youssef Ali', service: 'Sofa & carpet', datetime: 'Tomorrow 11:00', total: 'EGP 450', method: 'paid', state: 'ack', paid: true, payMethod: 'applepay', staff: 'Sara Nabil', svcIdx: 3, bucket: 'week' },
    ],
    cHistory: [
      { customer: 'Nour Hany', service: 'Deep clean', datetime: 'Fri 11 Jul · 09:00', total: 'EGP 720', status: 'upcoming', paid: true, method: 'instapay', staff: 'Ahmed Hassan', svcIdx: 1 },
      { customer: 'Karim Fouad', service: 'Move out', datetime: 'Wed 2 Jul · 12:00', total: 'EGP 540', status: 'past', paid: true, method: 'cash', staff: 'Mona Farid', svcIdx: 2 },
      { customer: 'Salma Adel', service: 'Standard', datetime: 'Mon 30 Jun · 16:00', total: 'EGP 280', status: 'past', paid: false, method: 'cash', staff: 'Sara Nabil', svcIdx: 0 },
    ],
    up_lic: false, up_id: false,
  }
}

export const THEME_VARS = {
  dark: { '--bg': '#0B1220', '--card': '#131C2E', '--ink': '#F2F5FA', '--soft': '#97A2B4', '--line': '#26324A', '--line2': '#1D2941', '--field': '#1A2740', '--muted': '#6B7890', '--navicon': '#55627A' },
  light: { '--bg': '#F6F8FC', '--card': '#ffffff', '--ink': '#0E1726', '--soft': '#5A6472', '--line': '#E6EBF2', '--line2': '#EEF2F7', '--field': '#F6F8FC', '--muted': '#8A93A3', '--navicon': '#B4BCCA' },
} as const
