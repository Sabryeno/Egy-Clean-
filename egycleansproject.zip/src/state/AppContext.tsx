import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import type { AppState, Screen } from './types'
import { initialState } from './data'
import { buildVals, type Api, type Vals } from './vals'

interface Ctx {
  state: AppState
  vals: Vals
}

const AppCtx = createContext<Ctx | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setStateRaw] = useState<AppState>(initialState)
  const stateRef = useRef(state)
  stateRef.current = state

  const setState = useCallback((partial: Partial<AppState>) => {
    setStateRaw((prev) => ({ ...prev, ...partial }))
  }, [])

  const set = useCallback(<K extends keyof AppState>(k: K, v: AppState[K]) => {
    setStateRaw((prev) => ({ ...prev, [k]: v }))
  }, [])

  const go = useCallback((screen: Screen) => {
    setStateRaw((prev) => ({ ...prev, screen }))
    const el = document.querySelector('.ph .scroll') as HTMLElement | null
    if (el) el.scrollTop = 0
  }, [])

  // Splash auto-advance (mirrors componentDidMount 1.9s timer)
  useEffect(() => {
    const t = setTimeout(() => {
      if (stateRef.current.screen === 'splash') setState({ screen: 'login' })
    }, 1900)
    return () => clearTimeout(t)
  }, [setState])

  const api: Api = { set, setState, go }
  const vals = buildVals(state, api)

  return <AppCtx.Provider value={{ state, vals }}>{children}</AppCtx.Provider>
}

export function useApp(): Ctx {
  const ctx = useContext(AppCtx)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}

export function useVals(): Vals {
  return useApp().vals
}
