import { useApp } from '../state/AppContext'
import { THEME_VARS } from '../state/data'
import { css } from '../lib/css'
import { Screens } from '../screens/Screens'
import { StickyBars } from './StickyBars'
import { Sheets } from './Sheets'
import type { CSSProperties } from 'react'

export function Phone() {
  const { state, vals } = useApp()
  const themeVars = THEME_VARS[state.theme] as unknown as CSSProperties

  const rootStyle: CSSProperties = {
    width: '390px', height: '830px', background: 'var(--bg)', borderRadius: '32px', overflow: 'hidden',
    position: 'relative', display: 'flex', flexDirection: 'column',
    boxShadow: '0 26px 60px -22px rgba(14,23,38,.5),0 0 0 1px rgba(14,23,38,.06)',
    ...themeVars,
  }

  return (
    <div className="stage">
      <div className="ph" dir={vals.dir} style={rootStyle}>
        {/* STATUS BAR */}
        <div style={css(`height:44px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 22px;font-weight:700;font-size:13.5px;position:relative;z-index:8;background:${vals.sbBg};color:${vals.sbInk}`)}>
          <span>9:41</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: vals.sbInk }}>
            <svg width="17" height="12" viewBox="0 0 17 12" fill="currentColor"><rect x="0" y="7" width="3" height="5" rx="1" /><rect x="4.5" y="4.5" width="3" height="7.5" rx="1" /><rect x="9" y="2" width="3" height="10" rx="1" /><rect x="13.5" y="0" width="3" height="12" rx="1" opacity=".4" /></svg>
            <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor"><circle cx="8" cy="9.5" r="1.7" /><path d="M8 2.5c2 0 3.8.8 5.1 2l1.4-1.4C13.8 1.4 11 0 8 0S2.2 1.4.5 3.1L1.9 4.5C3.2 3.3 6 2.5 8 2.5z" opacity=".85" /></svg>
            <svg width="26" height="13" viewBox="0 0 26 13" fill="none"><rect x=".5" y=".5" width="22" height="12" rx="3.5" stroke="currentColor" opacity=".45" /><rect x="2" y="2" width="17" height="9" rx="2" fill="currentColor" /><rect x="24" y="4" width="2" height="5" rx="1" fill="currentColor" opacity=".45" /></svg>
          </span>
        </div>

        {/* SCROLL AREA */}
        <div className="scroll" style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', position: 'relative' }}>
          <Screens />
        </div>

        {/* STICKY BOTTOMS + NAVS */}
        <StickyBars />

        {/* SHEETS (overlays) */}
        <Sheets />
      </div>
    </div>
  )
}
