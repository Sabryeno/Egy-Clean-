import { useVals } from '../state/AppContext'
import { css } from '../lib/css'

export function Sheets() {
  const v = useVals()
  return (
    <>
      {/* PROPERTY TYPE SHEET */}
      {v.propOpen && (
        <div onClick={v.closeProp} style={css('position:absolute;inset:0;z-index:20;background:rgba(14,23,38,.42);display:flex;flex-direction:column;justify-content:flex-end;animation:fadein .18s ease')}>
          <div onClick={v.stop} style={css('background:var(--card);border-radius:24px 24px 0 0;padding:20px 20px 24px;animation:slidein .25s ease')}>
            <div style={css('width:38px;height:4px;border-radius:30px;background:var(--line);margin:0 auto 16px')} />
            <div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{v.chooseWord}</div>
            <div style={css('display:flex;flex-direction:column;gap:9px;margin-top:16px')}>
              {v.propertyTypes.map((o, i) => (
                <div key={i} onClick={o.onSelect} style={css(`${o.chipStyle};border-radius:14px;padding:14px;display:flex;align-items:center;gap:11px;cursor:pointer`)}>
                  <span style={{ fontSize: '22px' }}>{o.emoji}</span>
                  <span style={css(`flex:1;font-weight:700;font-size:14px;color:${o.titleColor}`)}>{o.label}</span>
                  <span style={css(o.multStyle)}>{o.mult}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* FILTER SHEET */}
      {v.filterOpen && (
        <div onClick={v.closeFilter} style={css('position:absolute;inset:0;z-index:20;background:rgba(14,23,38,.42);display:flex;flex-direction:column;justify-content:flex-end;animation:fadein .18s ease')}>
          <div onClick={v.stop} style={css('background:var(--card);border-radius:24px 24px 0 0;padding:20px 20px 24px;animation:slidein .25s ease')}>
            <div style={css('width:38px;height:4px;border-radius:30px;background:var(--line);margin:0 auto 16px')} />
            <div style={css('display:flex;align-items:center;justify-content:space-between')}>
              <div style={css('font-weight:800;font-size:17px;color:var(--ink)')}>{v.filterWord}</div>
              <div onClick={v.resetFilter} style={css('font-size:12.5px;font-weight:700;color:#1E63FF;cursor:pointer')}>{v.resetWord}</div>
            </div>
            <div style={css('font-weight:800;font-size:11.5px;color:var(--soft);margin-top:18px;margin-bottom:9px;text-transform:uppercase;letter-spacing:.4px')}>{v.dateWord}</div>
            <div style={css('display:flex;gap:8px;flex-wrap:wrap')}>{v.dateOpts.map((o, i) => (<span key={i} onClick={o.onSel} style={css(o.style)}>{o.label}</span>))}</div>
            <div style={css('font-weight:800;font-size:11.5px;color:var(--soft);margin-top:16px;margin-bottom:9px;text-transform:uppercase;letter-spacing:.4px')}>{v.L.manageServices}</div>
            <div style={css('display:flex;gap:8px;flex-wrap:wrap')}>{v.svcOpts.map((o, i) => (<span key={i} onClick={o.onSel} style={css(o.style)}>{o.label}</span>))}</div>
            <div style={css('font-weight:800;font-size:11.5px;color:var(--soft);margin-top:16px;margin-bottom:9px;text-transform:uppercase;letter-spacing:.4px')}>{v.staffTitle}</div>
            <div style={css('display:flex;gap:8px;flex-wrap:wrap')}>{v.staffOpts.map((o, i) => (<span key={i} onClick={o.onSel} style={css(o.style)}>{o.label}</span>))}</div>
            <div onClick={v.closeFilter} style={css('margin-top:22px;background:#1E63FF;color:#fff;border-radius:14px;padding:16px;text-align:center;font-weight:800;font-size:15px;cursor:pointer')}>{v.applyWord}</div>
          </div>
        </div>
      )}
    </>
  )
}
