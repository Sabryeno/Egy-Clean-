import { css } from '../lib/css'

/** Back-chevron icon used across headers. `flip` is the vals.backFlip transform. */
export function BackArrow({ stroke, flip }: { stroke: string; flip: string }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ transform: flip }}>
      <path d="M15 5l-7 7 7 7" stroke={stroke} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/** Re-export for convenience */
export { css }
