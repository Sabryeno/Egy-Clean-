import { useVals } from '../state/AppContext'
import { css } from '../lib/css'

export function StickyBars() {
  const v = useVals()
  return (
    <>
      {v.isConfig && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);padding:12px 20px 20px;display:flex;align-items:center;gap:14px')}>
          <div style={{ flex: 1 }}>
            <div style={css('font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.4px')}>{v.L.estTotal}</div>
            <div style={css('font-weight:800;font-size:22px;color:#1E63FF')}>{v.estTotal}</div>
          </div>
          <div onClick={v.goSchedule} style={css('background:#1E63FF;color:#fff;border-radius:14px;padding:15px 26px;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 8px 18px -6px rgba(30,99,255,.6)')}>{v.L.continue}</div>
        </div>
      )}
      {v.isSchedule && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);padding:12px 20px 20px;display:flex;align-items:center;gap:14px')}>
          <div style={{ flex: 1 }}>
            <div style={css('font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.4px')}>{v.L.estTotal}</div>
            <div style={css('font-weight:800;font-size:22px;color:#1E63FF')}>{v.estTotal}</div>
          </div>
          <div onClick={v.goSummary} style={css('background:#1E63FF;color:#fff;border-radius:14px;padding:15px 26px;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 8px 18px -6px rgba(30,99,255,.6)')}>{v.L.review}</div>
        </div>
      )}
      {v.isVendor && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);padding:12px 20px 20px')}>
          <div onClick={v.startBooking} style={css('background:#1E63FF;color:#fff;border-radius:14px;padding:16px;font-weight:800;font-size:16px;text-align:center;cursor:pointer;box-shadow:0 8px 18px -6px rgba(30,99,255,.6)')}>{v.L.bookNow} · {v.co.priceLabel}{v.L.perHourShort}</div>
        </div>
      )}
      {v.isSummary && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);padding:12px 20px 20px')}>
          <div onClick={v.continueToPayment} style={css(`border-radius:14px;padding:16px;font-weight:800;font-size:15px;text-align:center;cursor:pointer;background:${v.payBtnBg};color:${v.payBtnColor}`)}>{v.L.continuePay} · {v.priceTotal}</div>
        </div>
      )}
      {v.isPayment && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);padding:12px 20px 20px')}>
          <div onClick={v.pay} style={css(`border-radius:14px;padding:16px;font-weight:800;font-size:16px;text-align:center;cursor:pointer;background:${v.payBtnBg};color:${v.payBtnColor};box-shadow:0 8px 18px -6px rgba(30,99,255,.5)`)}>{v.payBtnLabel}</div>
        </div>
      )}

      {/* CUSTOMER NAV */}
      {v.showCustNav && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);display:flex;justify-content:space-around;padding:10px 8px 20px')}>
          <div onClick={v.goHome} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navHome};cursor:pointer`)}><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 10.5L12 3l9 7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M5 9.5V20h14V9.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg><span style={{ fontSize: '10.5px', fontWeight: 700 }}>{v.L.navHome}</span></div>
          <div onClick={v.goSearch} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navSearch};cursor:pointer`)}><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" /><path d="M16.5 16.5L21 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span style={{ fontSize: '10.5px', fontWeight: 600 }}>{v.L.navSearch}</span></div>
          <div onClick={v.goBookings} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navBookings};cursor:pointer`)}><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="16" height="17" rx="3" stroke="currentColor" strokeWidth="2" /><path d="M8 3v3M16 3v3M8 12h8M8 16h5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span style={{ fontSize: '10.5px', fontWeight: 600 }}>{v.L.navBookings}</span></div>
          <div onClick={v.goAccount} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navAccount};cursor:pointer`)}><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="2" /><path d="M4 20c0-4 3.6-6 8-6s8 2 8 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span style={{ fontSize: '10.5px', fontWeight: 600 }}>{v.L.navProfile}</span></div>
        </div>
      )}

      {/* COMPANY NAV */}
      {v.showCompNav && (
        <div style={css('flex:none;background:var(--card);border-top:1px solid var(--line);display:flex;justify-content:space-around;padding:10px 4px 20px')}>
          <div onClick={v.goCHome} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navCHome};cursor:pointer`)}><svg width="21" height="21" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="2" /><rect x="13" y="3" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="2" /><rect x="3" y="13" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="2" /><rect x="13" y="13" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="2" /></svg><span style={{ fontSize: '10px', fontWeight: 600 }}>{v.L.navDashboard}</span></div>
          <div onClick={v.goCServices} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navCServices};cursor:pointer`)}><svg width="21" height="21" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M4 12h16M4 17h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span style={{ fontSize: '10px', fontWeight: 600 }}>{v.L.navServices}</span></div>
          <div onClick={v.goCHistory} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navCHistory};cursor:pointer`)}><svg width="21" height="21" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" /><path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span style={{ fontSize: '10px', fontWeight: 600 }}>{v.L.navHistory}</span></div>
          <div onClick={v.goCNotifs} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navCNotifs};cursor:pointer;position:relative`)}><svg width="21" height="21" viewBox="0 0 24 24" fill="none"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" /></svg><span style={{ fontSize: '10px', fontWeight: 600 }}>{v.L.navAlerts}</span></div>
          <div onClick={v.goCProfile} style={css(`display:flex;flex-direction:column;align-items:center;gap:4px;color:${v.navCProfile};cursor:pointer`)}><svg width="21" height="21" viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="2" /><path d="M8 9h8M8 13h5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span style={{ fontSize: '10px', fontWeight: 600 }}>{v.L.navProfile}</span></div>
        </div>
      )}
    </>
  )
}
