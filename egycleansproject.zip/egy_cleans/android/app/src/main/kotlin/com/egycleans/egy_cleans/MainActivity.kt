package com.egycleans.egy_cleans

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
